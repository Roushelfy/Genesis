"""Derive readable tables from the completed original primary audit."""
from collections import defaultdict
import json
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "meta/primary-throughput-v1-terminal-audit.json"
OUTPUT = ROOT / "meta/primary-throughput-summary-v1.json"
TABLE = ROOT / "meta/primary-throughput-tables-v1.md"


def main():
    if OUTPUT.exists() or TABLE.exists():
        raise FileExistsError("Use a fresh summary output.")
    document = json.loads(SOURCE.read_text())
    assert document["complete"] and document["passed"] and document["finished_rows"] == 102
    groups = defaultdict(list)
    for row in document["rows"]:
        groups[row["scope"], row["batch"], row["output"], row["route"]].append(row)
    cohorts = []
    for (scope, batch, output, route), rows in sorted(groups.items()):
        assert len(rows) == 3
        rates = [row["valid_transitions_per_second"] for row in rows]
        admitted = all(rate is not None for rate in rates)
        metric_totals = {}
        if scope == "policy" and admitted:
            keys = rows[0]["trajectory_metrics"]["totals"]
            metric_totals = {key: sum(row["trajectory_metrics"]["totals"][key] for row in rows) for key in keys}
        cohorts.append({
            "scope": scope, "batch": batch, "output": output, "route": route,
            "rows": [{"block": row["block"], "result": row["result"], "rate": row["valid_transitions_per_second"]} for row in rows],
            "qualified_rate": admitted,
            "rate_median": statistics.median(rates) if admitted else None,
            "rate_range": [min(rates), max(rates)] if admitted else None,
            "setup_seconds_median": statistics.median(row["setup_seconds"] for row in rows) if admitted else None,
            "timed_environment_steps": sum(row["repeat"]["steps"] * batch for row in rows) if admitted else None,
            "invalid_environment_steps": sum(row["repeat"]["invalid_environment_steps"] for row in rows) if admitted else None,
            "complete_policy_work_totals": metric_totals,
        })
    result = {
        "schema": "genesis.automatic-dpr-primary-summary.v1",
        "source_audit": str(SOURCE), "source_revision": document["source_revision"],
        "cohorts": cohorts, "paired_ratios": document["paired_ratios"],
        "qualified_processes": sum(row["valid_transitions_per_second"] is not None for row in document["rows"]),
        "retained_negative_processes": sum(row.get("expected_retained_negative", False) for row in document["rows"]),
        "scope": "Median and range across the three original same-device paired repeats. Ratios are paired before taking their median. Policy totals sum original reset-aware device observations. Failed warmups have no valid rate.",
    }
    OUTPUT.write_text(json.dumps(result, indent=2) + "\n")
    text = ["Rates are median environment transitions/s over three original repeats. Module transitions mean one recovery per environment.\n",
            "| Scope | B | Output | Adaptive | Angle128 | Edge16 | Planar shell | Pure rigid |",
            "| --- | ---: | --- | ---: | ---: | ---: | ---: | ---: |"]
    for scope in ("recovery", "policy"):
        for batch in (4, 8192):
            for output in ("max", "full"):
                values = []
                for route in ("volume_adaptive16", "volume_angle128", "volume_edge16_diagnostic", "shell_planar32", "pure_rigid"):
                    rows = [row for row in cohorts if row["scope"] == scope and row["batch"] == batch and row["route"] == route and (route == "pure_rigid" or row["output"] == output)]
                    if not rows:
                        values.append("n/a")
                    elif rows[0]["rate_median"] is None:
                        values.append("rejected")
                    else:
                        values.append(f"{rows[0]['rate_median']:,.1f}")
                text.append(f"| {scope} | {batch} | {output} | " + " | ".join(values) + " |")
    text.extend(["\nAdaptive / angle128 paired speed ratios:\n", "| Scope | B | Output | Median | Range |", "| --- | ---: | --- | ---: | --- |"])
    for row in document["paired_ratios"]:
        if row["comparator"] == "volume_angle128":
            assert row["complete_three_repeats"]
            text.append(f"| {row['scope']} | {row['batch']} | {row['output']} | {row['median']:.3f} | {row['range'][0]:.3f}-{row['range'][1]:.3f} |")
    TABLE.write_text("\n".join(text) + "\n")
    print(json.dumps({"output": str(OUTPUT), "table": str(TABLE), "qualified_processes": result["qualified_processes"], "retained_negatives": result["retained_negative_processes"]}))


if __name__ == "__main__":
    main()
