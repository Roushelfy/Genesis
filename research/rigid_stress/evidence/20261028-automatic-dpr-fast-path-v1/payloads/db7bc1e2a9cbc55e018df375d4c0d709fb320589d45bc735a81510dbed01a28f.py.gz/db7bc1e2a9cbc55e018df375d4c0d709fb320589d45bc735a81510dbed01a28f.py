"""Check optional profile snapshot CLI and unchanged default AST, stdlib only."""
import argparse,ast,contextlib,hashlib,io,json,subprocess,sys
from pathlib import Path
T=Path('/mnt/home/zhaofeng/workspace/Genesis/.worktrees/rigid-stress-recovery')
R=Path('/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta')
P=T/'research/rigid_stress/qipc_comparison/profile_planar_loading.py'
old=subprocess.check_output(['git','-C',str(T),'show','406e4deb1:research/rigid_stress/qipc_comparison/profile_planar_loading.py'],text=True)
new=P.read_text();tree=ast.parse(new);rows=[]
def check(n,v):rows.append({'name':n,'passed':bool(v)})
init=next(x for x in ast.walk(ast.parse((T/'examples/rigid/franka_egg_stress.py').read_text())) if isinstance(x,ast.FunctionDef) and x.name=='__init__')
defaults=dict(zip([x.arg for x in init.args.args][-len(init.args.defaults):],init.args.defaults))
newkwargs={'level','seed','varied','use_gjk_collision','enable_contact_patch','native_controller','timestep','substeps'}
call=next(x for x in ast.walk(tree) if isinstance(x,ast.Call) and ast.unparse(x.func)=='api.FrankaEgg')
for k in call.keywords:
 if k.arg in newkwargs:
  val=k.value.body if isinstance(k.value,ast.IfExp) else k.value
  check('explicit_default_'+k.arg,ast.dump(val)==ast.dump(defaults[k.arg]))
class Project(ast.NodeTransformer):
 def visit_ImportFrom(self,n):return None if n.module=='examples.speed_benchmark.rigid_stress_snapshot' else n
 def visit_Expr(self,n):
  if isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Attribute) and n.value.func.attr=='add_argument' and n.value.args and isinstance(n.value.args[0],ast.Constant) and n.value.args[0].value=='--module-snapshot':return None
  return self.generic_visit(n)
 def visit_Assign(self,n):
  if any(isinstance(x,ast.Name) and x.id in {'recipe','scene_warmup_steps','module_snapshot','module_warmup_calls','snapshot_prepare_seconds'} for x in n.targets):return None
  return self.generic_visit(n)
 def visit_If(self,n):
  if 'args.module_snapshot' in ast.unparse(n.test):
   out=[]
   for v in n.orelse:
    x=self.visit(v)
    if x is not None:out.extend(x if isinstance(x,list) else [x])
   return out
  return self.generic_visit(n)
 def visit_IfExp(self,n):
  if ast.unparse(n.test)=='recipe is None':return self.visit(n.body)
  return self.generic_visit(n)
 def visit_Name(self,n):
  return ast.Attribute(value=ast.Name(id='args',ctx=ast.Load()),attr='warmup',ctx=n.ctx) if n.id=='scene_warmup_steps' else n
 def visit_Call(self,n):
  if ast.unparse(n.func)=='api.FrankaEgg':n.keywords=[x for x in n.keywords if x.arg not in newkwargs]
  return self.generic_visit(n)
 def visit_Dict(self,n):
  drop={'module_snapshot','snapshot_rigid_recipe','scene_warmup_steps','module_warmup_calls','snapshot_preparation_seconds_including_IO_JIT'}
  items=[(k,v) for k,v in zip(n.keys,n.values) if not isinstance(k,ast.Constant) or k.value not in drop]
  n.keys=[k for k,v in items];n.values=[v for k,v in items]
  return self.generic_visit(n)
a=ast.parse(old);b=Project().visit(ast.parse(new));ast.fix_missing_locations(b)
check('entire_default_profile_module_AST_equal',ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False))
if not rows[-1]['passed']:
 (R/'profile-snapshot-projected-v1.py').write_text(ast.unparse(b)+'\n');(R/'profile-snapshot-original-v1.py').write_text(ast.unparse(a)+'\n')
def parse(argv):
 main=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='main');body=[]
 for x in main.body:
  if isinstance(x,ast.Expr) and isinstance(x.value,ast.Call) and ast.unparse(x.value.func)=='args.output.mkdir':break
  body.append(x)
 body.append(ast.Return(value=ast.Name(id='args',ctx=ast.Load())));mod=ast.Module(body=[ast.FunctionDef(name='parse',args=main.args,body=body,decorator_list=[])],type_ignores=[]);ast.fix_missing_locations(mod)
 ns={'argparse':argparse,'Path':Path,'json':json,'__doc__':'software CLI extraction'};exec(compile(mod,str(P),'exec'),ns)
 prev=sys.argv
 try:
  sys.argv=['profile',*argv]
  with contextlib.redirect_stderr(io.StringIO()):return ns['parse']()
 finally:sys.argv=prev
folder=R/'profile-snapshot-software-fixture-v1';folder.mkdir(exist_ok=False);(folder/'manifest.json').write_text(json.dumps({'bindings':{'recipe':{'software_only':True}}})+'\n')
base=['--conditions','unused-conditions.npz','--output','unused-output']
check('ordinary_CLI_default_snapshot_none',parse(base).module_snapshot is None)
check('module_snapshot_CLI_accepted',parse(base+['--module-snapshot',str(folder)]).module_snapshot==folder)
try:parse(base+['--scope','scene','--module-snapshot',str(folder)])
except SystemExit as e:check('moving_scene_snapshot_rejected',e.code==2)
else:check('moving_scene_snapshot_rejected',False)
check('no_getattr_hasattr',not any(isinstance(x,ast.Call) and isinstance(x.func,ast.Name) and x.func.id in ('getattr','hasattr') for x in ast.walk(tree)))
result={'schema':'genesis.module-snapshot-profile-controls.v1','passed':all(x['passed'] for x in rows),'control_count':len(rows),'rows':rows,'source_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'scope':'Stdlib actual argparse and AST controls only. No engine import, model, native kernels or trace execution. Shared-helper native QA remains independent.'}
p=R/'module-snapshot-profile-controls-v1.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(0 if result['passed'] else 1)
