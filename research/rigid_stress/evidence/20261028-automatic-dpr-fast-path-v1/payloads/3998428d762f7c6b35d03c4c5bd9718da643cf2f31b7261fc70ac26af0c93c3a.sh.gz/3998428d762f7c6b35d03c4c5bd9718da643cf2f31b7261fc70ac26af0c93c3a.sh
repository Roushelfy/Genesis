#!/usr/bin/env bash
set -euo pipefail
task_run=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2
test ! -e "$task_run"
mkdir -p "$task_run"
task_scratch=''
trap 'task_status=$?; printf "%s\n" "$task_status" > "$task_run/returncode.txt"; if test -n "$task_scratch"; then rm -rf -- "$task_scratch"; fi; exit "$task_status"' EXIT
trap 'exit 143' TERM
trap 'exit 130' INT
trap 'exit 129' HUP
task_scratch=$(mktemp -d /tmp/gs-shell-compare.XXXXXX)
task_cache="$task_scratch/cache"
task_tmp="$task_scratch/tmp"
printf "%s\n" "$task_scratch" > "$task_run/node-local-scratch.txt"
df -Pk "$task_scratch" > "$task_run/node-local-filesystem.txt"
mkdir -p "$task_tmp" "$task_cache"
export TMPDIR="$task_tmp" PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export GS_CACHE_FILE_PATH="$task_cache/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/quadrants"
export CUDA_CACHE_PATH="$task_cache/cuda" NUMBA_CACHE_DIR="$task_cache/numba"
export MPLCONFIGDIR="$task_cache/matplotlib"
export QIPC_RTC_CACHE="$task_cache/qipc_rtc"
export PYTHONPATH=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/analysis-source:/mnt/home/zhaofeng/workspace/Genesis/.worktrees/automatic-dpr-final-cli-v19
cd /mnt/home/zhaofeng/workspace/Genesis/.worktrees/automatic-dpr-final-cli-v19
export QD_GRAPH=0
campaign_status=0
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-policy-volume-angle128-B4-max.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-angle128-B4-max > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-angle128-B4-max.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-angle128-B4-max.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-angle128-B4-max.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-policy-shell-planar32-B4-max.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-shell-planar32-B4-max > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-shell-planar32-B4-max.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-shell-planar32-B4-max.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-shell-planar32-B4-max.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-policy-volume-adaptive16-B4-max.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-adaptive16-B4-max > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-adaptive16-B4-max.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-adaptive16-B4-max.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-adaptive16-B4-max.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-policy-volume-edge16-diagnostic-B4-max.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-edge16-diagnostic-B4-max > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-edge16-diagnostic-B4-max.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-edge16-diagnostic-B4-max.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-edge16-diagnostic-B4-max.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-recovery-volume-angle128-B4-max.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-angle128-B4-max > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-angle128-B4-max.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-angle128-B4-max.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-angle128-B4-max.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-recovery-shell-planar32-B4-max.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-shell-planar32-B4-max > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-shell-planar32-B4-max.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-shell-planar32-B4-max.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-shell-planar32-B4-max.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-recovery-volume-adaptive16-B4-max.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-adaptive16-B4-max > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-adaptive16-B4-max.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-adaptive16-B4-max.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-adaptive16-B4-max.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-recovery-volume-edge16-diagnostic-B4-max.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-edge16-diagnostic-B4-max > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-edge16-diagnostic-B4-max.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-edge16-diagnostic-B4-max.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-edge16-diagnostic-B4-max.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-policy-volume-angle128-B4-full.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-angle128-B4-full > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-angle128-B4-full.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-angle128-B4-full.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-angle128-B4-full.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-policy-shell-planar32-B4-full.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-shell-planar32-B4-full > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-shell-planar32-B4-full.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-shell-planar32-B4-full.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-shell-planar32-B4-full.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-policy-volume-adaptive16-B4-full.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-adaptive16-B4-full > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-adaptive16-B4-full.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-adaptive16-B4-full.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-adaptive16-B4-full.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-policy-volume-edge16-diagnostic-B4-full.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-edge16-diagnostic-B4-full > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-edge16-diagnostic-B4-full.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-edge16-diagnostic-B4-full.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-edge16-diagnostic-B4-full.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-recovery-volume-angle128-B4-full.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-angle128-B4-full > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-angle128-B4-full.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-angle128-B4-full.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-angle128-B4-full.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-recovery-shell-planar32-B4-full.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-shell-planar32-B4-full > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-shell-planar32-B4-full.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-shell-planar32-B4-full.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-shell-planar32-B4-full.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-recovery-volume-adaptive16-B4-full.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-adaptive16-B4-full > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-adaptive16-B4-full.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-adaptive16-B4-full.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-adaptive16-B4-full.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-recovery-volume-edge16-diagnostic-B4-full.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-edge16-diagnostic-B4-full > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-edge16-diagnostic-B4-full.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-edge16-diagnostic-B4-full.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-edge16-diagnostic-B4-full.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-policy-pure-rigid-B4.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-pure-rigid-B4 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-pure-rigid-B4.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-pure-rigid-B4.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-pure-rigid-B4.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-policy-volume-angle128-B8192-max.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-angle128-B8192-max > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-angle128-B8192-max.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-angle128-B8192-max.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-angle128-B8192-max.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-policy-shell-planar32-B8192-max.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-shell-planar32-B8192-max > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-shell-planar32-B8192-max.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-shell-planar32-B8192-max.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-shell-planar32-B8192-max.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-policy-volume-adaptive16-B8192-max.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-adaptive16-B8192-max > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-adaptive16-B8192-max.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-adaptive16-B8192-max.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-adaptive16-B8192-max.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-policy-volume-edge16-diagnostic-B8192-max.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-edge16-diagnostic-B8192-max > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-edge16-diagnostic-B8192-max.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-edge16-diagnostic-B8192-max.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-edge16-diagnostic-B8192-max.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-recovery-volume-angle128-B8192-max.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-angle128-B8192-max > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-angle128-B8192-max.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-angle128-B8192-max.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-angle128-B8192-max.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-recovery-shell-planar32-B8192-max.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-shell-planar32-B8192-max > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-shell-planar32-B8192-max.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-shell-planar32-B8192-max.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-shell-planar32-B8192-max.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-recovery-volume-adaptive16-B8192-max.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-adaptive16-B8192-max > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-adaptive16-B8192-max.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-adaptive16-B8192-max.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-adaptive16-B8192-max.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-recovery-volume-edge16-diagnostic-B8192-max.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-edge16-diagnostic-B8192-max > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-edge16-diagnostic-B8192-max.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-edge16-diagnostic-B8192-max.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-edge16-diagnostic-B8192-max.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-policy-volume-angle128-B8192-full.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-angle128-B8192-full > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-angle128-B8192-full.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-angle128-B8192-full.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-angle128-B8192-full.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-policy-shell-planar32-B8192-full.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-shell-planar32-B8192-full > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-shell-planar32-B8192-full.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-shell-planar32-B8192-full.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-shell-planar32-B8192-full.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-policy-volume-adaptive16-B8192-full.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-adaptive16-B8192-full > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-adaptive16-B8192-full.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-adaptive16-B8192-full.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-adaptive16-B8192-full.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-policy-volume-edge16-diagnostic-B8192-full.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-edge16-diagnostic-B8192-full > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-edge16-diagnostic-B8192-full.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-edge16-diagnostic-B8192-full.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-volume-edge16-diagnostic-B8192-full.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-recovery-volume-angle128-B8192-full.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-angle128-B8192-full > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-angle128-B8192-full.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-angle128-B8192-full.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-angle128-B8192-full.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-recovery-shell-planar32-B8192-full.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-shell-planar32-B8192-full > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-shell-planar32-B8192-full.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-shell-planar32-B8192-full.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-shell-planar32-B8192-full.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-recovery-volume-adaptive16-B8192-full.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-adaptive16-B8192-full > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-adaptive16-B8192-full.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-adaptive16-B8192-full.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-adaptive16-B8192-full.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-recovery-volume-edge16-diagnostic-B8192-full.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-edge16-diagnostic-B8192-full > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-edge16-diagnostic-B8192-full.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-edge16-diagnostic-B8192-full.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/recovery-volume-edge16-diagnostic-B8192-full.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/a62505e7aa53854e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_primary --task /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/primary-v4-inputs/block2-policy-pure-rigid-B8192.json --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-pure-rigid-B8192 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-pure-rigid-B8192.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-pure-rigid-B8192.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/primary-throughput-v1/group2/policy-pure-rigid-B8192.returncode.txt
  campaign_status=1
fi
exit "$campaign_status"
