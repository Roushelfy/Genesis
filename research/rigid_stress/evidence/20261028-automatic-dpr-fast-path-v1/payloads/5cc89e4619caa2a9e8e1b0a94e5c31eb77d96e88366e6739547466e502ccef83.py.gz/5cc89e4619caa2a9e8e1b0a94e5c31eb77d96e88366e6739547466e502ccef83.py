"""Exercise serialization/selection guards with NumPy software views; no native execution."""
import array
import ast
import dataclasses
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
from typing import NamedTuple

sys.path.insert(0, '/mnt/data/zhaofeng/venvs/vbench/lib/python3.10/site-packages')
import numpy as np

T = Path('/mnt/home/zhaofeng/workspace/Genesis/.worktrees/rigid-stress-recovery')
R = Path('/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path')
P = T/'examples/speed_benchmark/rigid_stress_snapshot.py'
OUT = R/'meta/module-snapshot-software-controls-v1'
OUT.mkdir(exist_ok=False)

class View:
    def __init__(self, value): self.value = value
    @property
    def shape(self): return self.value.shape
    @property
    def dtype(self): return 'torch.' + self.value.dtype.name
    @property
    def device(self): return 'software'
    def __getitem__(self, ids): return View(self.value[ids])
    def __setitem__(self, ids, other): self.value[ids] = other.value
    def copy_(self, other): np.copyto(self.value,other.value,casting='no')
    def to(self, device): assert device=='software';return View(self.value.copy())

class Torch:
    @staticmethod
    def from_numpy(value): return View(value)
class QD:
    Tensor=object
    @staticmethod
    def sync(): pass
@dataclasses.dataclass
class Field:
    view: View
    shape: tuple
@dataclasses.dataclass
class Options:
    def model_dump(self,mode): return {'software_fixture':True}
@dataclasses.dataclass
class Link:
    idx: int=1
    stress_options: Options=dataclasses.field(default_factory=Options)
@dataclasses.dataclass
class Entry: link: Link
@dataclasses.dataclass
class Recovery: links: tuple
@dataclasses.dataclass
class ColliderState:
    n_contacts: Field
    contact_sort_idx: Field
@dataclasses.dataclass
class Collider: collider_state: ColliderState
@dataclasses.dataclass
class Solver:
    collider: Collider
    stress_recovery: Recovery
@dataclasses.dataclass
class Scene: rigid_solver: Solver
@dataclasses.dataclass
class Workload:
    scene: Scene
    link: Link
    fields: tuple
    tick: int=730
    n_envs: int=2
class GS: __file__=str(T/'genesis/__init__.py')

def qd_to_torch(field,transpose,copy): assert transpose and copy is False;return field.view
def qd_to_numpy(field,transpose,copy): assert transpose and copy is True;return field.view.value.copy()
def tensor_to_array(view): return view.value

source=P.read_text(); tree=ast.parse(source)
nodes=[x for x in tree.body if not isinstance(x,(ast.Import,ast.ImportFrom))]
ns={'__file__':str(P),'np':np,'qd':QD,'torch':Torch,'gs':GS,'FrankaEgg':object,'NamedTuple':NamedTuple,
    'dataclasses':dataclasses,'hashlib':hashlib,'json':json,'Path':Path,'sys':sys,
    'os':__import__('os'),'platform':__import__('platform'),'subprocess':subprocess,
    'qd_to_torch':qd_to_torch,'qd_to_numpy':qd_to_numpy,'tensor_to_array':tensor_to_array}
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(P),'exec'),ns)
RawField=ns['RawField']
def fixture():
    count=Field(View(np.array([2,1],dtype=np.int32)),(2,))
    order=np.full((2,5),-1,dtype=np.int32);order[0,:2]=[4,1];order[1,0]=2
    sort=Field(View(order),(5,2))
    force=np.arange(30,dtype=np.float64).reshape((2,5,3));force[0,4,0]=-0.0
    force[0,4,1]=np.frombuffer(bytes.fromhex('420000000000f87f'),dtype=np.float64)[0]
    force=Field(View(force),(5,2))
    linkpos=Field(View(np.arange(18,dtype=np.float64).reshape((2,3,3))),(3,2))
    geoms=Field(View(np.arange(24,dtype=np.float64).reshape((2,4,3))),(4,2))
    link=Link();solver=Solver(Collider(ColliderState(count,sort)),Recovery((Entry(link),)))
    fields=(RawField('collider.n_contacts',count,'complete'),RawField('collider.contact_sort_idx',sort,'contact_rank'),
            RawField('collider.contact_data.force',force,'contact_slot'),RawField('links.pos',linkpos,'observed_link'),
            RawField('geoms.aabb_min',geoms,'complete'))
    return Workload(Scene(solver),link,fields)
ns['raw_fields']=lambda w:w.fields
rows=[]
def check(name,value,detail=None):
    rows.append({'name':name,'passed':bool(value),'detail':detail})
def refuses(name,call):
    try: call()
    except ValueError as e: check(name,True,str(e))
    else: check(name,False,'expected ValueError')

a=np.array([-0.0,0.0],dtype=np.float64)
check('signed_zero_identity_distinguished',ns['array_identity'](a[:1])!=ns['array_identity'](a[1:]))
producer=fixture();sel=ns['contact_selection'](producer)
check('nonprefix_sort_slots_exact',sel.slot.tolist()==[4,1,2])
check('nonuniform_environment_rank_exact',sel.environment.tolist()==[0,0,1] and sel.rank.tolist()==[0,1,0])
binding={'software_fixture':True,'physical_constant':1.0}
folder=OUT/'original';receipt=ns['save_module_snapshot'](producer,folder,binding,{'software_only':True})
with np.load(folder/'raw-inputs.npz',allow_pickle=False) as z:
    check('only_active_slots_serialized',z['collider.contact_data.force'].shape==(3,3))
    check('nan_payload_and_signed_zero_preserved',z['collider.contact_data.force'][0,:2].tobytes()==producer.fields[2].value.view.value[0,4,:2].tobytes())
consumer=fixture()
for field in consumer.fields:field.value.view.value.fill(0)
consumer.fields[3].value.view.value.fill(999)
restored=ns['restore_module_snapshot'](consumer,folder,binding)
check('restore_raw_digest_exact',restored['raw_input_sha256']==receipt['raw_input_sha256'])
check('unobserved_links_untouched',(consumer.fields[3].value.view.value[:,[0,2]]==999).all())
check('inactive_contact_capacity_excluded',(consumer.fields[2].value.view.value[0,[0,2,3]]==0).all())
check('nan_signed_zero_roundtrip_after_restore',consumer.fields[2].value.view.value[0,4,:2].tobytes()==producer.fields[2].value.view.value[0,4,:2].tobytes())
check('native_declared_shape_retained',json.loads((folder/'manifest.json').read_text())['fields'][2]['native_shape']==[2,5,3])
refuses('different_bindings_rejected',lambda:ns['restore_module_snapshot'](fixture(),folder,{'software_fixture':False}))
wrong=fixture();wrong.fields[2].value.view=View(np.zeros((2,6,3)));wrong.fields[2].value.shape=(6,2)
refuses('different_native_shape_rejected',lambda:ns['restore_module_snapshot'](wrong,folder,binding))
wrong=fixture();wrong.fields[2].value.view=View(np.zeros((2,5,3),dtype=np.float32))
refuses('different_native_dtype_rejected',lambda:ns['restore_module_snapshot'](wrong,folder,binding))
corrupt=OUT/'corrupt';shutil.copytree(folder,corrupt)
b=(corrupt/'raw-inputs.npz').read_bytes();(corrupt/'raw-inputs.npz').write_bytes(b[:-1]+bytes([b[-1]^1]))
refuses('payload_byte_corruption_rejected',lambda:ns['restore_module_snapshot'](fixture(),corrupt,binding))
consumer.fields[2].value.view.value[0,4,0]=0.0
refuses('active_signed_zero_change_rejected',lambda:ns['verify_module_snapshot'](consumer,folder))
ns['restore_module_snapshot'](consumer,folder,binding)
consumer.fields[2].value.view.value[0,0,0]=123.0
check('unread_inactive_change_is_out_of_scope',ns['verify_module_snapshot'](consumer,folder)==receipt['raw_input_sha256'])
consumer.fields[4].value.view.value[0,0,0]+=1
refuses('geom_aabb_change_rejected',lambda:ns['verify_module_snapshot'](consumer,folder))
bad=fixture();bad.scene.rigid_solver.collider.collider_state.contact_sort_idx.view.value[0,:2]=[4,4]
refuses('duplicate_raw_slot_rejected',lambda:ns['contact_selection'](bad))
bad=fixture();bad.scene.rigid_solver.collider.collider_state.contact_sort_idx.view.value[0,0]=5
refuses('outside_capacity_raw_slot_rejected',lambda:ns['contact_selection'](bad))
bad=fixture();bad.scene.rigid_solver.collider.collider_state.n_contacts.view.value[0]=6
refuses('outside_capacity_count_rejected',lambda:ns['contact_selection'](bad))
manifest=json.loads((folder/'manifest.json').read_text())
check('no_fitted_stress_state_in_payload',all(not any(s in x['name'] for s in ('coefficient','stress_tensor','elastic','displacement')) for x in manifest['fields']))
result={'schema':'genesis.module-snapshot-software-controls.v1','complete':True,'passed':all(x['passed'] for x in rows),
        'software_only':True,'scientific_qualification':False,'control_count':len(rows),'rows':rows,
        'scope':'AST-executed actual helper functions, actual NumPy1.26.4 NPZ serialization and CPU software views emulate Torch/Quadrants interfaces. No Genesis import/init, kernels, solver or GPU interop exercised; native Slurm smoke remains required.',
        'source':{'path':str(P),'bytes':P.stat().st_size,'sha256':hashlib.sha256(P.read_bytes()).hexdigest()},
        'numpy':{'version':np.__version__,'path':np.__file__},'test_script':{'path':__file__,'sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}}
(OUT/'result.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({'passed':result['passed'],'controls':len(rows),'failed':[x for x in rows if not x['passed']],'path':str(OUT/'result.json')}))
raise SystemExit(0 if result['passed'] else 1)
