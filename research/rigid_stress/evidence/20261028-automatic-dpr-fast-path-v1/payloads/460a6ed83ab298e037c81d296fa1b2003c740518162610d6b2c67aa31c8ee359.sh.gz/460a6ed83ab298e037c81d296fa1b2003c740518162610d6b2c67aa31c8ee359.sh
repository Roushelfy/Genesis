#!/usr/bin/env bash
set -euo pipefail
task_run=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/adaptive-native-corpus-v8/group1
test ! -e "$task_run"
mkdir -p "$task_run"
task_scratch=''
trap 'task_status=$?; printf "%s\n" "$task_status" > "$task_run/returncode.txt"; if test -n "$task_scratch"; then rm -rf -- "$task_scratch"; fi; exit "$task_status"' EXIT
trap 'exit 143' TERM
trap 'exit 130' INT
trap 'exit 129' HUP
task_scratch=$(mktemp -d /tmp/gs-shell-compare.XXXXXX)
task_cache="$task_scratch/cache"
task_tmp="$task_scratch/tmp"
printf "%s\n" "$task_scratch" > "$task_run/node-local-scratch.txt"
df -Pk "$task_scratch" > "$task_run/node-local-filesystem.txt"
mkdir -p "$task_tmp" "$task_cache"
export TMPDIR="$task_tmp" PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export GS_CACHE_FILE_PATH="$task_cache/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/quadrants"
export CUDA_CACHE_PATH="$task_cache/cuda" NUMBA_CACHE_DIR="$task_cache/numba"
export MPLCONFIGDIR="$task_cache/matplotlib"
export QIPC_RTC_CACHE="$task_cache/qipc_rtc"
export PYTHONPATH=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/adaptive-native-corpus-v8/analysis-source:/mnt/home/zhaofeng/workspace/Genesis/.worktrees/automatic-dpr-adaptive-v8
cd /mnt/home/zhaofeng/workspace/Genesis/.worktrees/automatic-dpr-adaptive-v8
export QD_GRAPH=0
campaign_status=0
export GS_CACHE_FILE_PATH="$task_cache/cd36d7a94a20cab4/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/cd36d7a94a20cab4/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_adaptive_replay --reference-run /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/manual-finite-controls-v1/group1/convex-tip-finite-rules --modes cached --fixed-controls edge16 angle128 --budgets /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/application-budgets-v1.json --git-source /mnt/home/zhaofeng/workspace/Genesis/.worktrees/automatic-dpr-adaptive-v8 --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/adaptive-native-corpus-v8/group1/case03-convex-tip-finite-rules > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/adaptive-native-corpus-v8/group1/case03-convex-tip-finite-rules.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/adaptive-native-corpus-v8/group1/case03-convex-tip-finite-rules.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/adaptive-native-corpus-v8/group1/case03-convex-tip-finite-rules.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/cd36d7a94a20cab4/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/cd36d7a94a20cab4/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_adaptive_replay --reference-run /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/manual-finite-controls-v1/group2/u-inner-seam-finite-rules --modes cached --fixed-controls edge16 angle128 --budgets /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/application-budgets-v1.json --git-source /mnt/home/zhaofeng/workspace/Genesis/.worktrees/automatic-dpr-adaptive-v8 --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/adaptive-native-corpus-v8/group1/case04-u-inner-seam-finite-rules > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/adaptive-native-corpus-v8/group1/case04-u-inner-seam-finite-rules.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/adaptive-native-corpus-v8/group1/case04-u-inner-seam-finite-rules.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/adaptive-native-corpus-v8/group1/case04-u-inner-seam-finite-rules.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/cd36d7a94a20cab4/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/cd36d7a94a20cab4/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.qipc_comparison.dpr_fast_adaptive_replay --reference-run /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/manual-finite-controls-v1/group3/u-gap-finite-rules --modes cached --fixed-controls edge16 angle128 --budgets /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta/application-budgets-v1.json --git-source /mnt/home/zhaofeng/workspace/Genesis/.worktrees/automatic-dpr-adaptive-v8 --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/adaptive-native-corpus-v8/group1/case05-u-gap-finite-rules > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/adaptive-native-corpus-v8/group1/case05-u-gap-finite-rules.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/adaptive-native-corpus-v8/group1/case05-u-gap-finite-rules.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/adaptive-native-corpus-v8/group1/case05-u-gap-finite-rules.returncode.txt
  campaign_status=1
fi
exit "$campaign_status"
