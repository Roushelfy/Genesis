"""Project the optional snapshot branch away and compare the original benchmark AST."""
import ast,copy,hashlib,json,subprocess
from pathlib import Path
T=Path('/mnt/home/zhaofeng/workspace/Genesis/.worktrees/rigid-stress-recovery')
R=Path('/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta')
p=T/'examples/speed_benchmark/rigid_stress.py'
old=subprocess.check_output(['git','-C',str(T),'show','779402b44:examples/speed_benchmark/rigid_stress.py'],text=True)
new=p.read_text()
DROP={'snapshot_group','snapshot_directory','prepared_snapshot','module_snapshot','snapshot_prepare_seconds','module_warmup_calls','scene_warmup_steps'}
class Project(ast.NodeTransformer):
 def visit_ImportFrom(self,n):
  if n.module=='examples.speed_benchmark.rigid_stress_snapshot':return None
  return n
 def visit_Assign(self,n):
  if any(isinstance(x,ast.Name) and x.id in DROP for x in n.targets):return None
  return self.generic_visit(n)
 def visit_Expr(self,n):
  if isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Attribute) and isinstance(n.value.func.value,ast.Name) and n.value.func.value.id=='snapshot_group':return None
  return self.generic_visit(n)
 def visit_If(self,n):
  test=ast.unparse(n.test)
  if test=='restore_input' or test=='snapshot_check is None':
   out=[]
   for x in n.body:
    v=self.visit(x)
    if isinstance(v,list):out.extend(v)
    elif v is not None:out.append(v)
   return out
  if test=='snapshot_directory is not None':return None
  return self.generic_visit(n)
 def visit_IfExp(self,n):
  test=ast.unparse(n.test)
  if test in ('prepared_snapshot is None','snapshot_prepare_seconds is None'):return self.visit(n.body)
  if test=='snapshot_directory is not None':return self.visit(n.orelse)
  return self.generic_visit(n)
 def visit_Name(self,n):
  if n.id=='scene_warmup_steps':return ast.Attribute(value=ast.Name(id='args',ctx=ast.Load()),attr='warmup',ctx=n.ctx)
  return n
 def visit_Dict(self,n):
  reject={'physical_source_column_identities','ordered_target_anchor_identity','ordered_target_anchor_face_identity','declared_scene_warmup_steps','module_warmup_calls','module_snapshot'}
  items=[(k,v) for k,v in zip(n.keys,n.values) if not isinstance(k,ast.Constant) or k.value not in reject]
  n.keys=[k for k,v in items];n.values=[v for k,v in items]
  return self.generic_visit(n)
 def visit_Call(self,n):
  if isinstance(n.func,ast.Name) and n.func.id in ('prepare_recovery_snapshot','profile'):
   n.args=n.args[:2 if n.func.id=='prepare_recovery_snapshot' else 3]
   n.keywords=[k for k in n.keywords if k.arg not in ('restore_input','snapshot_check')]
  return self.generic_visit(n)
 def visit_FunctionDef(self,n):
  if n.name in ('prepare_recovery_snapshot','profile'):
   count=2 if n.name=='prepare_recovery_snapshot' else 3
   n.args.args=n.args.args[:count]
   n.args.defaults=n.args.defaults[:1] if n.name=='prepare_recovery_snapshot' else []
  return self.generic_visit(n)
a=ast.parse(old);b=Project().visit(ast.parse(new));ast.fix_missing_locations(b)
checks=[]
for name in ['prepare_recovery_snapshot','profile','main']:
 x=next(x for x in a.body if isinstance(x,ast.FunctionDef) and x.name==name)
 y=next(x for x in b.body if isinstance(x,ast.FunctionDef) and x.name==name)
 same=ast.dump(x,include_attributes=False)==ast.dump(y,include_attributes=False)
 checks.append({'name':name,'projected_AST_equal':same})
 if not same:
  (R/(name+'-snapshot-projected-v1.py')).write_text(ast.unparse(y)+'\n')
  (R/(name+'-snapshot-original-v1.py')).write_text(ast.unparse(x)+'\n')
print(json.dumps(checks))
result={'schema':'genesis.module-snapshot-default-projection.v1','passed':all(x['projected_AST_equal'] for x in checks),'old_revision':'779402b44','new_source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'scope':'The known optional snapshot branch is projected away. Additional untimed source-identity metadata is omitted. The remaining original preparation/profile/main control flow must be AST equal. This is static software evidence, not native execution.','checks':checks,'projection_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
q=R/'module-snapshot-default-projection-v1.json';assert not q.exists();q.write_text(json.dumps(result,indent=2)+'\n')
raise SystemExit(0 if result['passed'] else 1)
