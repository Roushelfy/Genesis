"""Independently verify compressed payloads, requirement coverage and all original primary rows."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path


def digest(content):
    return hashlib.sha256(content).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--packet", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    packet = args.packet.resolve()
    checksums = []
    for line in (packet / "SHA256SUMS").read_text().splitlines():
        expected, name = line.split("  ", 1)
        path = packet / name
        assert path.resolve().is_relative_to(packet), name
        actual = digest(path.read_bytes())
        assert actual == expected, name
        checksums.append(name)
    assert set(checksums) == {str(p.relative_to(packet)) for p in packet.rglob("*") if p.is_file() and p.name != "SHA256SUMS"}
    index = json.loads(gzip.decompress((packet / "index.json.gz").read_bytes()))
    ledger = json.loads((packet / "requirements-ledger.json").read_text())
    artifacts = {row["path"]: row for row in index["artifacts"]}
    checked = {}
    for row in index["artifacts"]:
        if "payload" in row:
            if row["payload"] not in checked:
                content = gzip.decompress((packet / row["payload"]).read_bytes())
                checked[row["payload"]] = len(content), digest(content)
            assert checked[row["payload"]] == (row["bytes"], row["sha256"]), row["path"]
    assert len(ledger["requirements"]) == 22 and all(row["satisfied"] for row in ledger["requirements"])
    identities = []
    for row in ledger["requirements"]:
        for expected in row["evidence_identities"]:
            actual = artifacts[expected["path"]]
            assert "payload" in actual, expected["path"]
            assert (actual["bytes"], actual["sha256"]) == (expected["bytes"], expected["sha256"]), expected["path"]
            identities.append(expected["path"])
    primary = [row for row in index["tasks"] if row["campaign"] == "primary-throughput-v1"]
    assert len(primary) == 102
    repeats, failures = 0, 0
    for row in primary:
        directory = Path(index["run"]) / row["campaign"] / f"group{row['group']}" / row["task"]["name"]
        result_id = artifacts[str(directory / "result.json")]
        result = json.loads(gzip.decompress((packet / result_id["payload"]).read_bytes()))
        assert result["complete"] and result["task_definition"]["args"]
        if result["passed"]:
            assert row["returncode"] == 0
            original = result["benchmark"]
            benchmark_id = artifacts[original["path"]]
            assert (benchmark_id["bytes"], benchmark_id["sha256"]) == (original["bytes"], original["sha256"])
            benchmark = json.loads(gzip.decompress((packet / benchmark_id["payload"]).read_bytes()))
            assert len(benchmark["repeats"]) == 1
            assert benchmark["repeats"][0]["invalid_environment_steps"] == 0
            repeats += 1
        else:
            assert row["returncode"] == 1 and result["benchmark"] is None
            assert "status=3" in result["driver_error"]["message"] and result["failure_snapshot"]["available"]
            failures += 1
    assert repeats == 90 and failures == 12
    total = sum(p.stat().st_size for p in packet.rglob("*") if p.is_file())
    assert total <= 10 * 1024 * 1024
    result = {"schema": "genesis.automatic-dpr-packet-verification.v1", "passed": True,
              "packet": str(packet), "packet_bytes": total, "checksum_files": len(checksums),
              "decoded_unique_payloads": len(checked), "retained_requirement_evidence": len(set(identities)),
              "campaigns": index["campaigns"], "tasks": len(index["tasks"]),
              "original_primary_rows": len(primary), "original_valid_repeats": repeats,
              "original_failures": failures,
              "checksum_manifest_sha256": digest((packet / "SHA256SUMS").read_bytes()),
              "scope": "Independent standard-library packet integrity and exact primary retention check. Numerical and physical qualifications remain those of the reviewed ledger and original audits."}
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
