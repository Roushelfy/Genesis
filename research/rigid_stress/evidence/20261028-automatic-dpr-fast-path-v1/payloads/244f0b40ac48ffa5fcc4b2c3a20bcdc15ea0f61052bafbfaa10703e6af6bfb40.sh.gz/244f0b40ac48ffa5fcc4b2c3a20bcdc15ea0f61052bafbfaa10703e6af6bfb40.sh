#!/usr/bin/env bash
set -euo pipefail
task_run=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v1/group0
test ! -e "$task_run"
mkdir -p "$task_run"
task_scratch=''
trap 'task_status=$?; printf "%s\n" "$task_status" > "$task_run/returncode.txt"; if test -n "$task_scratch"; then rm -rf -- "$task_scratch"; fi; exit "$task_status"' EXIT
trap 'exit 143' TERM
trap 'exit 130' INT
trap 'exit 129' HUP
task_scratch=$(mktemp -d /tmp/gs-shell-compare.XXXXXX)
task_cache="$task_scratch/cache"
task_tmp="$task_scratch/tmp"
printf "%s\n" "$task_scratch" > "$task_run/node-local-scratch.txt"
df -Pk "$task_scratch" > "$task_run/node-local-filesystem.txt"
mkdir -p "$task_tmp" "$task_cache"
export TMPDIR="$task_tmp" PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export GS_CACHE_FILE_PATH="$task_cache/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/quadrants"
export CUDA_CACHE_PATH="$task_cache/cuda" NUMBA_CACHE_DIR="$task_cache/numba"
export MPLCONFIGDIR="$task_cache/matplotlib"
export QIPC_RTC_CACHE="$task_cache/qipc_rtc"
export PYTHONPATH=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v1/analysis-source:/mnt/home/zhaofeng/workspace/Genesis/.worktrees/automatic-dpr-snapshot-v9
cd /mnt/home/zhaofeng/workspace/Genesis/.worktrees/automatic-dpr-snapshot-v9
export QD_GRAPH=0
campaign_status=0
export GS_CACHE_FILE_PATH="$task_cache/41a4920332130e0e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/41a4920332130e0e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m examples.speed_benchmark.rigid_stress --scope recovery --envs 4 --conditions /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261019-qualified-ranking/hard-finite-edge-franka-boundary-v2/group0/franka/conditions.npz --egg-geometry mesh64 --box-edge-policy planar --radius-model hertz --pressure-profile hertz --warmup 730 --steps 3 --repetitions 1 --minimum-seconds 0 --seed 510000 --inverse-precision 64 --history 0 --compact-log --summarize-warmup --source-revision 406e4deb1b922a5aae9040ce965bcd847b5d65d9 --stress-backend volume --pressure-quadrature adaptive --quadrature 16 --output-mode full --save-module-snapshot /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v1/inputs/B4 --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v1/group0/producer-adaptive-full.json > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v1/group0/producer-adaptive-full.json.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v1/group0/producer-adaptive-full.json.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v1/group0/producer-adaptive-full.json.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/41a4920332130e0e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/41a4920332130e0e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m examples.speed_benchmark.rigid_stress --scope recovery --envs 4 --conditions /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261019-qualified-ranking/hard-finite-edge-franka-boundary-v2/group0/franka/conditions.npz --egg-geometry mesh64 --box-edge-policy planar --radius-model hertz --pressure-profile hertz --warmup 730 --steps 3 --repetitions 1 --minimum-seconds 0 --seed 510000 --inverse-precision 64 --history 0 --compact-log --summarize-warmup --source-revision 406e4deb1b922a5aae9040ce965bcd847b5d65d9 --stress-backend volume --pressure-quadrature adaptive --quadrature 16 --output-mode full --module-snapshot /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v1/inputs/B4 --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v1/group0/consumer-adaptive-full.json > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v1/group0/consumer-adaptive-full.json.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v1/group0/consumer-adaptive-full.json.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v1/group0/consumer-adaptive-full.json.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/41a4920332130e0e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/41a4920332130e0e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m examples.speed_benchmark.rigid_stress --scope recovery --envs 4 --conditions /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261019-qualified-ranking/hard-finite-edge-franka-boundary-v2/group0/franka/conditions.npz --egg-geometry mesh64 --box-edge-policy planar --radius-model hertz --pressure-profile hertz --warmup 730 --steps 3 --repetitions 1 --minimum-seconds 0 --seed 510000 --inverse-precision 64 --history 0 --compact-log --summarize-warmup --source-revision 406e4deb1b922a5aae9040ce965bcd847b5d65d9 --stress-backend volume --pressure-quadrature angle --quadrature 128 --output-mode max --module-snapshot /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v1/inputs/B4 --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v1/group0/consumer-angle128-max.json > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v1/group0/consumer-angle128-max.json.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v1/group0/consumer-angle128-max.json.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v1/group0/consumer-angle128-max.json.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/41a4920332130e0e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/41a4920332130e0e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m examples.speed_benchmark.rigid_stress --scope recovery --envs 4 --conditions /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261019-qualified-ranking/hard-finite-edge-franka-boundary-v2/group0/franka/conditions.npz --egg-geometry mesh64 --box-edge-policy planar --radius-model hertz --pressure-profile hertz --warmup 730 --steps 3 --repetitions 1 --minimum-seconds 0 --seed 510000 --inverse-precision 64 --history 0 --compact-log --summarize-warmup --source-revision 406e4deb1b922a5aae9040ce965bcd847b5d65d9 --stress-backend volume --pressure-quadrature edge --quadrature 16 --output-mode max --module-snapshot /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v1/inputs/B4 --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v1/group0/consumer-edge16-max.json > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v1/group0/consumer-edge16-max.json.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v1/group0/consumer-edge16-max.json.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v1/group0/consumer-edge16-max.json.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/41a4920332130e0e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/41a4920332130e0e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m examples.speed_benchmark.rigid_stress --scope recovery --envs 4 --conditions /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261019-qualified-ranking/hard-finite-edge-franka-boundary-v2/group0/franka/conditions.npz --egg-geometry mesh64 --box-edge-policy planar --radius-model hertz --pressure-profile hertz --warmup 730 --steps 3 --repetitions 1 --minimum-seconds 0 --seed 510000 --inverse-precision 64 --history 0 --compact-log --summarize-warmup --source-revision 406e4deb1b922a5aae9040ce965bcd847b5d65d9 --stress-backend shell --shell-loading q4 --pressure-quadrature edge --quadrature 10 --output-mode full --module-snapshot /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v1/inputs/B4 --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v1/group0/consumer-shell-q4-full.json > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v1/group0/consumer-shell-q4-full.json.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v1/group0/consumer-shell-q4-full.json.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v1/group0/consumer-shell-q4-full.json.returncode.txt
  campaign_status=1
fi
export GS_CACHE_FILE_PATH="$task_cache/41a4920332130e0e/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/41a4920332130e0e/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m examples.speed_benchmark.rigid_stress --scope recovery --envs 4 --conditions /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261019-qualified-ranking/hard-finite-edge-franka-boundary-v2/group0/franka/conditions.npz --egg-geometry mesh64 --box-edge-policy planar --radius-model hertz --pressure-profile hertz --warmup 730 --steps 3 --repetitions 1 --minimum-seconds 0 --seed 510000 --inverse-precision 64 --history 0 --compact-log --summarize-warmup --source-revision 406e4deb1b922a5aae9040ce965bcd847b5d65d9 --stress-backend shell --shell-loading planar --loading-subdivisions 32 --pressure-quadrature edge --quadrature 10 --scatter-tasks-per-env 128 --planar-integration radial --planar-query blocks --output-mode full --module-snapshot /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v1/inputs/B4 --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v1/group0/consumer-shell-planar32-full.json > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v1/group0/consumer-shell-planar32-full.json.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v1/group0/consumer-shell-planar32-full.json.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v1/group0/consumer-shell-planar32-full.json.returncode.txt
  campaign_status=1
fi
exit "$campaign_status"
