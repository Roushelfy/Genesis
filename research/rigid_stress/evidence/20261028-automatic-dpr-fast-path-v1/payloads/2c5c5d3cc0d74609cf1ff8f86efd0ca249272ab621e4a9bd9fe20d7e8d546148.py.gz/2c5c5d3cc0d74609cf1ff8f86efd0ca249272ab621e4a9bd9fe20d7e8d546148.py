"""Bind the reviewed 22 requirements to their completed evidence."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def identity(path):
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def main():
    target = ROOT / "meta/requirements-final-v2.json"
    if target.exists():
        raise FileExistsError(target)
    gates = {
        "primary-throughput-v1-terminal-audit.json": ("complete", "passed"),
        "native-trajectory-complete-v3-terminal-audit.json": ("complete", "passed"),
        "adaptive-uniform-corpus-v1-terminal-audit.json": ("complete", "passed"),
        "authored-continuation-v3-terminal-audit.json": ("complete", "passed", "continuation_qualified"),
        "own-process-memory-v3-terminal-audit.json": ("passed",),
        "common-input-profiles-v2-terminal-audit.json": ("passed",),
        "final-default-public-terminal-audit-v1.json": ("all_final_routes_passed",),
        "final-public-shell-v2-terminal-audit.json": ("complete", "passed"),
        "preservation-final-v1.json": ("passed",),
        "final-owned-static-v3.json": ("passed",),
        "final-documentation-v1.json": ("passed",),
    }
    for name, keys in gates.items():
        doc = json.loads((ROOT / "meta" / name).read_text())
        assert all(doc[key] is True for key in keys), name
    old = json.loads((ROOT / "meta/requirements-progress-v5.json").read_text())
    reviews = {
        "R01": ("Exact frame221 diagnosis", "Independent sampled-support infeasibility and native residual/iteration diagnostics; original whole-array trace negative retained."),
        "R02": ("Exact policy tick606 diagnosis", "Original env2/slot0 mechanics and failure retained; nearby captures preserve actual angular velocity and all contact sources."),
        "R03": ("Practical error budgets declared before selection", "5% tensor/5% peak/2% underestimation, absolute and three regional errors, independent reference-stability controls; old budgets remain separately reported."),
        "R04": ("Bounded integration and stopping-tolerance study", "Original 1e-9/1e-7/1e-5 sweep and cheaper rules distinguish infeasible support from inaccurate converged fits; no production tolerance relaxation selected."),
        "R05": ("Online admission calibration and switching", "44-pair source-node study: zero false accepts and 11 conservative false rejects; all three inaccurate coarse controls rejected. Native primitives and a 41-point path exercise the operator and eight switches. Finite empirical scope only."),
        "R06": ("Source-local repair without mixed provisional loads", "Final selection precedes one scatter; cached/uncached/serial/forced-overflow tests preserve loads and release/reload. Original nonlinear timeouts remain explicit."),
        "R07": ("Native Quadrants implementation and original elasticity", "Original K, material, F/application-point M, residual, max/full and acceptance gates pass final frozen and complete-history controls."),
        "R08": ("Changing and nonconvex physical controls", "All12 frozen inputs and20 CPU/CUDA loaded tests cover asymmetric, cavity/material-side, normal/friction and original-point moment behavior within their declared geometry scope."),
        "R09": ("Lifecycle and environment isolation", "Final48 default/lifecycle test executions and eight complete histories pass reset, checkpoint, release/recontact and batch controls."),
        "R10": ("Same-mechanics full-field accuracy", "Exact native frozen-input and trajectory comparisons retain global/loaded/remote full-tensor and sampled-peak errors, original omega and all prior strict negatives."),
        "R11": ("Complete scripted and actual policy histories", "Final eight1200-step B4/B64 max/full histories pass across326400 environment-frames. All positive sources remain at q16, so switching qualification comes from the separate authored path."),
        "R12": ("Matched primary throughput and original failures", "All102 original fresh processes audited in three same-device paired blocks: module/policy, B4/B8192, max/full, adaptive/edge16/angle128/planar/pure rigid. Failed warmups have no qualified rate; all repeated rates and vectors retained."),
        "R13": ("Combined-path profiles and work accounting", "Final common-input profiles bind actual adaptive source routing. Complete reset-aware device observations retain candidates/checkers, fit work, repairs, rejections and overflow work. Intrusive profiles remain outside primary timing."),
        "R14": ("Memory and preparation cost", "Final adaptive own-PID memory and native shared/per-environment accounting plus original comparator measurements retain sample scope, setup cost and every failed row. All primary rates use valid/attempted accounting."),
        "R15": ("Public physical defaults", "Ordinary Options/dpr select pressure/patch/Hertz/Hertz; volume remains backend default and shell Q4 remains loading default."),
        "R16": ("Actual workload and CLI default inheritance", "Omitted options reach public Options; actual choices are recorded. Real default/public CLI commands pass. Unconfigured links do not gain stress recovery."),
        "R17": ("Explicit manual, legacy, strict and SCR contexts", "Focused context tests and complete manual6mm/legacy and angle128 commands pass. Explicit quadrature keeps fixed edge behavior when the rule is omitted."),
        "R18": ("Qualified cheap default and explicit sharp-edge policy", "Adaptive angular16 with independently fitted8/16/64 admission and selective64/128 repair is the qualified volume default. Original gates and unsupported-geometry policy remain; sharp-box planar surrogate stays explicit."),
        "R19": ("Short runnable volume and shell examples", "Real730-step public volume/shell B64/max headless and B1/full viewer commands pass. The guide specifies material, shell thickness/k32, shapes/units, import order and legacy/reference overrides."),
        "R20": ("Focused regression coverage", "Final48 CPU/CUDA default/lifecycle and20 loaded controls pass, with separate deterministic-curvature controls; these are test execution counts, not a sum of unique test definitions."),
        "R21": ("Current recommendations and delivery documentation", "GOAL, README, AGENTS, API, running guide and results give one measured configuration per backend, speed/error/memory tradeoffs and discrete/continuum limits."),
        "R22": ("Preservation, storage and reproducibility", "Original12 files, prior64 and campaign21 frozen sources, and all69 source/helper inventories pass read-only checks. Runtime data stay under data; exact sources, original failures and reproduction inputs remain available."),
    }
    additions = {
        "R05": ["meta/authored-continuation-v3-terminal-audit.json"],
        "R07": ["meta/native-trajectory-complete-v3-terminal-audit.json"],
        "R09": ["meta/native-trajectory-complete-v3-terminal-audit.json", "meta/final-default-public-terminal-audit-v1.json"],
        "R11": ["meta/native-trajectory-complete-v3-terminal-audit.json"],
        "R12": ["meta/primary-throughput-v1-terminal-audit.json", "meta/primary-throughput-summary-v1.json"],
        "R13": ["meta/primary-throughput-v1-terminal-audit.json"],
        "R14": ["meta/primary-throughput-summary-v1.json", "meta/own-process-memory-v1-terminal-audit.json"],
        "R16": ["meta/final-default-public-terminal-audit-v1.json"],
        "R18": ["meta/primary-throughput-summary-v1.json"],
        "R19": ["meta/final-default-public-terminal-audit-v1.json", "meta/final-public-shell-v2-terminal-audit.json"],
        "R20": ["meta/final-owned-static-v3.json", "meta/final-default-public-terminal-audit-v1.json"],
        "R21": ["meta/final-documentation-v1.json", "meta/primary-throughput-summary-v1.json"],
        "R22": ["meta/preservation-final-v1.json", "meta/final-owned-static-v3.json"],
    }
    rows = []
    for row in old["requirements"]:
        code = row["id"]
        evidence = list(dict.fromkeys(row["evidence"] + additions.get(code, [])))
        rows.append({"id": code, "requirement": reviews[code][0], "satisfied": True,
                     "decision": reviews[code][1], "evidence": evidence,
                     "evidence_identities": [identity(ROOT / name) for name in evidence]})
    result = {"schema": "genesis.automatic-dpr-requirements-final.v1", "created_utc": datetime.now(timezone.utc).isoformat(),
              "goal_source_revision": old["goal_source_revision"], "measured_source_revision": "070cb0c96386250dda3a85db703d5705d5c3fccc",
              "requirements": rows, "all22_satisfied": len(rows) == 22 and all(row["satisfied"] for row in rows),
              "scope": "Reviewed implementation/evidence decisions. Packet checksum/link validation and normal branch publication follow before the active goal is closed.",
              "goal_complete": False, "builder": identity(Path(__file__))}
    target.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"output": identity(target), "satisfied": len(rows)}))


if __name__ == "__main__":
    main()
