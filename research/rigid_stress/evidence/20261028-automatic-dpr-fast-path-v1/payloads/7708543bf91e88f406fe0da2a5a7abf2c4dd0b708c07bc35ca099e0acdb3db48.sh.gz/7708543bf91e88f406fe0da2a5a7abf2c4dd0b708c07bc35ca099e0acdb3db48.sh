#!/usr/bin/env bash
set -euo pipefail
task_run=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/actual-benchmark-smoke-v1/group0
test ! -e "$task_run"
mkdir -p "$task_run"
task_scratch=''
trap 'task_status=$?; printf "%s\n" "$task_status" > "$task_run/returncode.txt"; if test -n "$task_scratch"; then rm -rf -- "$task_scratch"; fi; exit "$task_status"' EXIT
trap 'exit 143' TERM
trap 'exit 130' INT
trap 'exit 129' HUP
task_scratch=$(mktemp -d /tmp/gs-shell-compare.XXXXXX)
task_cache="$task_scratch/cache"
task_tmp="$task_scratch/tmp"
printf "%s\n" "$task_scratch" > "$task_run/node-local-scratch.txt"
df -Pk "$task_scratch" > "$task_run/node-local-filesystem.txt"
mkdir -p "$task_tmp" "$task_cache"
export TMPDIR="$task_tmp" PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export GS_CACHE_FILE_PATH="$task_cache/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/quadrants"
export CUDA_CACHE_PATH="$task_cache/cuda" NUMBA_CACHE_DIR="$task_cache/numba"
export MPLCONFIGDIR="$task_cache/matplotlib"
export QIPC_RTC_CACHE="$task_cache/qipc_rtc"
export PYTHONPATH=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/actual-benchmark-smoke-v1/analysis-source:/mnt/home/zhaofeng/workspace/Genesis/.worktrees/automatic-dpr-adaptive-v6
cd /mnt/home/zhaofeng/workspace/Genesis/.worktrees/automatic-dpr-adaptive-v6
export QD_GRAPH=0
campaign_status=0
export GS_CACHE_FILE_PATH="$task_cache/32395850c6bdd2f0/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/32395850c6bdd2f0/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m examples.speed_benchmark.rigid_stress --scope recovery --envs 4 --conditions /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261019-qualified-ranking/hard-finite-edge-franka-boundary-v2/group0/franka/conditions.npz --egg-geometry mesh64 --box-edge-policy planar --pressure-quadrature adaptive --quadrature 16 --warmup 8 --steps 2 --minimum-seconds 0 --repetitions 1 --compact-log --source-revision d0ad2ad162928dc49a3d422b893892420712c128 --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/actual-benchmark-smoke-v1/group0/actual-benchmark-recovery > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/actual-benchmark-smoke-v1/group0/actual-benchmark-recovery.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/actual-benchmark-smoke-v1/group0/actual-benchmark-recovery.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/actual-benchmark-smoke-v1/group0/actual-benchmark-recovery.returncode.txt
  campaign_status=1
fi
exit "$campaign_status"
