"""Read existing terminal history artifacts; no engine imports or scientific execution."""
import argparse
import array
import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import subprocess
import sys
import zipfile

R = Path('/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path')
C = R / 'native-trajectory-complete-v3'
SOURCE = 'f0fd49a01b65c4ed0715dae18d8ff2d3d6878c0a'


def identity(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': h.hexdigest()}


def load(z, name):
    with z.open(name + '.npy') as f:
        sig = f.read(8)
        if sig[:6] != b'\x93NUMPY' or sig[6:] not in (b'\x01\x00', b'\x02\x00', b'\x03\x00'):
            raise ValueError('Unsupported NPY encoding')
        size = int.from_bytes(f.read(2 if sig[6:] == b'\x01\x00' else 4), 'little')
        header = ast.literal_eval(f.read(size).decode().strip())
        raw = f.read()
    if header['fortran_order']:
        raise ValueError('Unexpected Fortran-order history array')
    dtype = header['descr']
    values = array.array({'<f8': 'd', '<f4': 'f', '<i8': 'q', '<i4': 'i', '|b1': 'B'}[dtype])
    values.frombytes(raw)
    if sys.byteorder != 'little' and dtype[0] == '<':
        values.byteswap()
    if len(values) != math.prod(header['shape']):
        raise ValueError('Array shape/bytes mismatch')
    return header['shape'], values, dtype, raw


def audit_case(group, task, slurm):
    path = C / ('group' + str(group)) / task['name'] / 'result.json'
    d = json.loads(path.read_text())
    if slurm['state'] != 'COMPLETED' or slurm['exit_code'] != '0:0' or d.get('complete') is not True:
        return {'group': group, 'name': task['name'], 'terminal_qualified_artifacts': False, 'slurm': slurm,
                'complete': d.get('complete'), 'passed': d.get('passed'), 'rows': len(d.get('rows', [])),
                'live_or_incomplete_artifacts_not_hashed': True, 'error': d.get('error')}
    b = d['arguments']['envs']
    t = d['arguments']['steps']
    rows = d['rows']
    out = {'group': group, 'name': task['name'], 'terminal_qualified_artifacts': True, 'slurm': slurm,
           'identities': [identity(path), identity(path.parent / 'all-steps.npz'), identity(path.parent / 'all-valid-source-rows.npz')],
           'result_flags': {k: d.get(k) for k in ('complete', 'passed', 'bounded_history_qualified', 'full_trajectory_qualified', 'all_environments_complete_600_step_cycle', 'source_files_unchanged', 'input_files_unchanged')},
           'rows': len(rows), 'consecutive_steps_exact': [x['step'] for x in rows] == list(range(t)),
           'source_revision': d['source_revision'], 'worker': d['worker'], 'budgets': d['budgets'], 'conditions': d['conditions'],
           'row_false_counts': {k: sum(x[k] is not True for x in rows) for k in ('passed', 'numerical_passed', 'application_regions_passed', 'same_mechanics_max_full_passed', 'inputs_target_state_rigid_unchanged', 'route_counters_accounted', 'legacy_parity_passed', 'legacy_strict_origin_diagnostic_passed')},
           'history_environment_counts': d['history_environment_counts'], 'history_coverage': d['history_coverage'],
           'per_environment': {k: d[k] for k in ('loaded_seen', 'release_seen', 'recontact_seen', 'reset_counts')},
           'lifecycle': d['lifecycle'], 'legacy_spatial_5mean_10worst_5peak': d['legacy_spatial_5mean_10worst_5peak'],
           'legacy_spatial_5mean_10worst_5peak_passed': d['legacy_spatial_5mean_10worst_5peak_passed'], 'legacy_parity_passed': d['legacy_parity_passed'],
           'witness_count': len(d['witnesses']), 'witness_failed': sum(x['passed'] is not True or x['raw_reconstruction_passed'] is not True for x in d['witnesses']),
           'policy': d.get('policy'), 'primary_timing': d['primary_timing']}
    with zipfile.ZipFile(path.parent / 'all-steps.npz') as z:
        shape, a, _, _ = load(z, 'runtime')
        assert shape == (t, 3, 9, b)
        out['runtime_false_by_route_and_flag'] = {r: {n: sum(not a[((i*3+ri)*9+fi)*b+e] for i in range(t) for e in range(b)) for fi,n in enumerate(d['array_contract']['runtime_flags'])} for ri,r in enumerate(d['array_contract']['runtime_routes'])}
        shape, a, _, _ = load(z, 'original_source_max_force_moment_relative')
        assert shape == (t, 3, 2, b)
        out['source_max_relative_F_original_point_M'] = {r: [max(a[((i*3+ri)*2+mi)*b+e] for i in range(t) for e in range(b)) for mi in range(2)] for ri,r in enumerate(d['array_contract']['runtime_routes'])}
        _, a, _, _ = load(z, 'original_elastic_residual')
        out['original_K_absolute_residual_max'] = {r: max(a[(i*3+ri)*b+e] for i in range(t) for e in range(b)) for ri,r in enumerate(d['array_contract']['runtime_routes'])}
        _, a, _, _ = load(z, 'legacy')
        out['legacy_metric_maxima'] = {n: max(a[(i*5+mi)*b+e] for i in range(t) for e in range(b)) for mi,n in enumerate(d['array_contract']['legacy_metrics'])}
        shape, a, _, _ = load(z, 'route_counters')
        assert shape == (t, b, 9)
        out['route_counter_totals'] = {n: sum(a[(i*b+e)*9+mi] for i in range(t) for e in range(b)) for mi,n in enumerate(d['route_counter_columns'])}
        _, regions, _, _ = load(z, 'regions')
        _, samples, _, _ = load(z, 'region_samples')
        out['weighted_full9_regions'] = {}
        for ri,n in enumerate(d['array_contract']['regions']):
            active = [(i,e) for i in range(t) for e in range(b) if samples[(i*b+e)*3+ri]]
            out['weighted_full9_regions'][n] = {'evaluated_environment_frames': len(active), 'empty_environment_frames': t*b-len(active), 'maxima': {m: max((regions[((i*b+e)*3+ri)*10+mi] for i,e in active), default=None) for mi,m in enumerate(d['array_contract']['region_metrics']) if mi in (0,2,6,7,8)}, 'all_evaluated_metrics_finite': all(math.isfinite(regions[((i*b+e)*3+ri)*10+mi]) for i,e in active for mi in range(10))}
    with zipfile.ZipFile(path.parent / 'all-valid-source-rows.npz') as z:
        keys = ['step','environment','slot','anchor_face','force','radius','force_error','moment_error','status','admission__rule','admission__attempts','evaluations']
        arrays = {k: load(z,k)[1] for k in keys}
        count = len(arrays['step'])
        positive = [i for i in range(count) if math.hypot(*arrays['force'][3*i:3*i+3]) > 1e-30]
        out['raw_sources'] = {'valid_source_records': count, 'positive_force_source_records': len(positive), 'status_counts': dict(Counter(arrays['status'])), 'selected_rule_counts': dict(Counter(arrays['admission__rule'])), 'attempt_counts': dict(Counter(arrays['admission__attempts'])), 'final_newton_evaluation_counts': dict(Counter(arrays['evaluations'])), 'source_force_error_max_N': max(arrays['force_error'],default=0), 'source_original_point_moment_error_max_Nm': max(arrays['moment_error'],default=0), 'source_original_point_gate_failures': sum(not (arrays['force_error'][i] <= 1e-8*math.hypot(*arrays['force'][3*i:3*i+3]) and arrays['moment_error'][i] <= 1e-8*math.hypot(*arrays['force'][3*i:3*i+3])*arrays['radius'][i]) for i in positive)}
        previous, adjacent, switches, same_anchor_switches = {}, 0, [], []
        for i in positive:
            key = arrays['environment'][i], arrays['slot'][i]
            old = previous.get(key)
            if old is not None and arrays['step'][i] == arrays['step'][old]+1:
                adjacent += 1
                if arrays['admission__rule'][i] != arrays['admission__rule'][old]:
                    row = {'step': arrays['step'][i], 'environment': key[0], 'slot': key[1], 'old_rule': arrays['admission__rule'][old], 'new_rule': arrays['admission__rule'][i], 'same_anchor': arrays['anchor_face'][old] == arrays['anchor_face'][i]}
                    switches.append(row)
                    if row['same_anchor']: same_anchor_switches.append(row)
            previous[key] = i
        switch_env_frames = sorted({(x['step'], x['environment']) for x in switches})
        jumps = []
        for step,env in switch_env_frames:
            before = regions[((step-1)*b+env)*30:((step-1)*b+env)*30+10]
            after = regions[(step*b+env)*30:(step*b+env)*30+10]
            jumps.append({'step': step, 'environment': env, 'global_tensor_relative_error_before_after': [before[2],after[2]], 'global_signed_peak_error_jump_Pa': after[5]-before[5], 'peak_error_jump_over_max_reference_peak': abs(after[5]-before[5])/max(before[3],after[3],1.0)})
        out['route_switching'] = {'switch_environment_frames': len(switch_env_frames), 'first_switch_error_rows': jumps[:10], 'maximum_normalized_peak_error_jump_at_switch': max((x['peak_error_jump_over_max_reference_peak'] for x in jumps),default=None), 'continuity_measurement_scope': 'Adjacent per-frame weighted field norm and signed peak error; not a full temporal tensor-difference or identical-input rule-switch experiment.', 'adjacent_positive_env_slot_pairs': adjacent, 'rule_change_count': len(switches), 'same_anchor_rule_change_count': len(same_anchor_switches), 'first_rule_changes': switches[:10], 'continuity_applicability': 'exercised_requires_separate_jump_analysis' if switches else 'not_exercised', 'scope': 'Adjacent occupied env/slot observations; unchanged slot/anchor alone does not prove one persistent physical contact. No-switch histories do not qualify transition continuity.'}
    frames = sorted({x['path'] for x in d['keyframes']})
    out['saved_raw_keyframe_checks'] = {'count': len(frames), 'per_route': {}}
    for route in d['array_contract']['runtime_routes']:
        worst = 0.0
        for frame in frames:
            with zipfile.ZipFile(Path(frame)/(route+'-runtime.npz')) as z:
                _,a,_,_ = load(z,'elastic_residual'); _,bud,_,_ = load(z,'original_elastic_residual_budget')
                worst = max(worst,max((x/y for x,y in zip(a,bud)),default=0))
        out['saved_raw_keyframe_checks']['per_route'][route] = {'maximum_K_residual_over_original_budget': worst}
    out['audit_passed'] = (all(v is True for v in out['result_flags'].values()) and len(rows)==t==1200 and out['consecutive_steps_exact'] and d['source_revision']==SOURCE and not out['witness_failed'] and all(out['per_environment'][k][e] for k in ('loaded_seen','release_seen','recontact_seen','reset_counts') for e in range(b)) and all(x['maximum_K_residual_over_original_budget'] <= 1 for x in out['saved_raw_keyframe_checks']['per_route'].values()) and all(not v for k,v in out['row_false_counts'].items() if k not in ('legacy_parity_passed','legacy_strict_origin_diagnostic_passed')) and all(not v for row in out['runtime_false_by_route_and_flag'].values() for k,v in row.items() if k!='strict_origin_diagnostic_passed') and not out['raw_sources']['source_original_point_gate_failures'] and all(v['all_evaluated_metrics_finite'] for v in out['weighted_full9_regions'].values()))
    return out


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    if args.output.exists(): raise FileExistsError(args.output)
    manifest=R/'meta/native-trajectory-complete-v3-tasks.json'
    tasks=json.loads(manifest.read_text())
    sacct=subprocess.check_output(['sacct','-j','760072','-n','-P','--format=JobID,State,ExitCode,Elapsed'],text=True)
    status={p[0]: {'state':p[1],'exit_code':p[2],'elapsed':p[3]} for line in sacct.splitlines() if (p:=line.split('|')) and '.' not in p[0]}
    rows=[audit_case(g,group[0],status.get('760072_'+str(g),{'state':'UNKNOWN','exit_code':None,'elapsed':None})) for g,group in enumerate(tasks)]
    out={'schema':'genesis.dpr-fast-native-trajectory-existing-artifact-audit.v1','created_utc':datetime.now(timezone.utc).isoformat(),'job_id':760072,'source_revision':SOURCE,'manifest':identity(manifest),'audit_tool':identity(Path(__file__)),'row_count':len(rows),'terminal_rows':sum(x['terminal_qualified_artifacts'] for x in rows),'complete':len(rows)==8 and all(x['terminal_qualified_artifacts'] for x in rows),'passed':len(rows)==8 and all(x.get('audit_passed') is True for x in rows),'goal_complete':False,'scope':'Read existing terminal artifacts only. Full tensor comparison is intrusive accuracy, not throughput. Angular128 per-frame native reference is not a continuum certificate. Old parity and origin diagnostics remain independent. Transition continuity requires observed switches; no switch is not a pass. No live outputs were hashed.','rows':rows,'sacct':sacct}
    out['qualification_scope'] = 'Numerical, application-field and lifecycle complete-history audit only; excludes a positive continuous-switching claim and excludes old strict parity equivalence.'
    out['continuous_switching_evidence'] = {'observed_rule_changes': sum(x.get('route_switching', {}).get('rule_change_count', 0) for x in rows), 'qualification_claimed': False, 'scope': 'Per-case actual change counts and adjacent error statistics are retained. No observed change is not evidence of transition continuity.'}
    out['previous_source_independent_audits_for_scope_only'] = [identity(R/'meta'/n) for n in ('native-trajectory-complete-v1-b4-independent-fields-audit.json', 'native-trajectory-complete-v1-historical-policy-scope.json')]
    args.output.write_text(json.dumps(out,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
    print(json.dumps({'output':identity(args.output),'complete':out['complete'],'passed':out['passed'],'terminal_rows':out['terminal_rows']}))


if __name__=='__main__': main()
