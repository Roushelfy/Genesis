"""Standard-library receipt extraction; no native/scientific execution."""
import hashlib
import json
import math
from pathlib import Path
import xml.etree.ElementTree as ET

R = Path('/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path')
E8 = 'a9e52d4f355868f74e9c0ef3e27c6fb6e1c3ccda'
E4 = '55327ea52d3658453c7359e00de0c90f6241c3b4'

def identity(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for part in iter(lambda: f.read(1024 * 1024), b''):
            h.update(part)
    return {'path': str(p), 'bytes': p.stat().st_size, 'sha256': h.hexdigest()}

def read(p):
    return json.loads(p.read_text())

def write(name, value):
    p = R / 'meta' / name
    if p.exists():
        raise FileExistsError(p)
    tmp = p.with_suffix(p.suffix + '.tmp')
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    tmp.replace(p)
    print(json.dumps(identity(p)))

def numbers(v):
    if isinstance(v, list):
        for x in v:
            yield from numbers(x)
    elif isinstance(v, (int, float)) and not isinstance(v, bool):
        if not math.isfinite(v):
            raise ValueError('nonfinite diagnostic')
        yield v

def maxval(v):
    return max(numbers(v), default=0)

def mode_summary(m):
    op = m['independent_stage_operator_check']
    life = m.get('lifecycle')
    checks = {
        'worker_passed': m['passed'] is True,
        'worker_complete': m['complete'] is True,
        'physical_input_bytes_unchanged': all(v is True for v in m['physical_inputs_bitwise_unchanged'].values()),
        'source_F_1e-8': maxval(m['force_error_relative']) <= 1e-8,
        'original_point_M_1e-8': maxval(m['original_point_moment_error_relative']) <= 1e-8,
        'original_K_residual': all(a <= b for a, b in zip(m['K_residual'], m['K_residual_budget'], strict=True)),
        'independent_operator_parity_1e-8': op['passed'] is True and op['absolute_score_parity_tolerance'] == 1e-8 and op['maximum_comparable_absolute_difference'] <= 1e-8,
        'unchanged_admission_threshold': op['admission_threshold_unchanged'] == 1e-3,
        'application_fields': all(v is True for v in m['application_passed_per_environment']),
        'public_valid': all(v is True for v in m['public_valid_per_environment']),
        'scheduling_control': m['scheduling_control']['passed'] is True,
        'lifecycle': life is None or life['passed'] is True,
    }
    return {
        'mode': m['mode'], 'passed': all(checks.values()), 'checks': checks,
        'force_error_relative_max': maxval(m['force_error_relative']),
        'original_point_moment_error_relative_max': maxval(m['original_point_moment_error_relative']),
        'K_residual': m['K_residual'], 'K_residual_budget': m['K_residual_budget'],
        'operator_score_absolute_difference_max': op['maximum_comparable_absolute_difference'],
        'workspace_count': m['workspace_actual_count'], 'workspace_capacity': m['workspace_capacity'],
        'overflow_calls': m['workspace_overflow_calls'], 'application_regions': m['application_regions'],
        'old_numerical_parity_passed_per_environment': m['legacy_volume_parity_passed_per_environment'],
        'old_numerical_parity_errors': m['legacy_errors'],
        'old_spatial_worst10_peak5_passed_per_environment': m['original_spatial_worst10_peak5_passed_per_environment'],
        'old_spatial_mean5_passed': m['original_spatial_mean5_passed'],
        'lifecycle_phases': None if life is None else {k: {'passed': life[k]['passed'], 'complete': life[k]['complete']} for k in ['release', 'reload']},
        'admission_counter_columns': m['admission_counter_columns'], 'admission_counter_delta': m['admission_counter_delta'],
        'intrusive_seconds_including_runtime_JIT': m['intrusive_seconds_including_runtime_JIT'],
    }

p = R / 'adaptive-loaded-v8'
assert read(p / 'source.json')['revision'] == E8
records = []
expected = {f'test_adaptive_pressure_wrench_release_and_partial_reset[{geom}-{cap}-{coop}]' for geom in ['u', 'cavity'] for cap in [1,32] for coop in ['False', 'True']}
for i, backend in enumerate(['cpu', 'gpu']):
    q = p / f'group{i}' / f'v4-loaded-{backend}'
    rc = q.with_suffix('.returncode.txt')
    result = read(q / 'result.json')
    cases = list(ET.parse(q / 'junit.xml').iter('testcase'))
    names = {c.attrib['name'] for c in cases}
    ok = int(rc.read_text()) == 0 and result['passed'] is True and result['exit_code'] == 0 and len(cases) == 8 and names == expected and all(len(c) == 0 for c in cases)
    assert ok
    records.append({'backend': backend, 'passed': ok, 'tests': len(cases), 'test_names': sorted(names), 'returncode': identity(rc), 'result': identity(q / 'result.json'), 'junit': identity(q / 'junit.xml'), 'start': identity(q / 'start.json')})
write('adaptive-loaded-v8-terminal-audit.json', {'schema':'genesis.adaptive-loaded-terminal-audit.v1','complete':True,'passed':all(x['passed'] for x in records),'source_revision':E8,'job':759624,'tests':16,'records':records,'source':identity(p/'source.json'),'tasks':identity(p/'tasks.json'),'scope':'Native CPU/GPU cap1/cap32 U/cavity scalar/cooperative strict F/original-point M/K/fullfield and release/slot/partial-reset controls. No corpus/default/performance claim.','science_executed_here':False})

p = R / 'adaptive-conformance-v8'
records = []
for q in sorted(p.glob('group*/*/result.json')):
    d = read(q)
    rc = q.parent.with_suffix('.returncode.txt')
    assert d['source_revision'] == E8 and int(rc.read_text()) == 0
    modes = [mode_summary(m) for m in d['modes']]
    assert {m['mode'] for m in modes} == {'cached','uncached','serial','overflow'}
    assert all(m['passed'] for m in modes) and d['complete'] is True and d['passed'] is True
    assert all(m['overflow_calls'] == (1 if m['mode'] == 'overflow' else 0) for m in modes)
    records.append({'name':q.parent.name,'result':identity(q),'returncode':identity(rc),'passed':True,'modes':modes,'model_all_arrays_bitwise_equal':d['original_model_all_arrays_bitwise_equal'],'physical_inputs':d['physical_inputs'],'reference_result':d['reference_result'],'whole_frame_qualification':d['whole_frame_qualification'],'mechanical_scope':d['mechanical_scope'],'authored_manual_control':d['authored_manual_control']})
assert len(records) == 2
write('adaptive-conformance-v8-terminal-audit.json', {'schema':'genesis.adaptive-conformance-terminal-audit.v1','complete':True,'passed':True,'source_revision':E8,'job':759627,'records':records,'source':identity(p/'source.json'),'tasks':identity(p/'tasks.json'),'scope':'Two frozen GPU physical inputs x four scheduling routes plus release/permuted reload, unchanged strict source/K/operator/field gates; old cross-rule numerical parity remains separately reported. CPU arithmetic-model conformance is in its separate E6 receipt. No default/primary-performance qualification.','science_executed_here':False})

for version, engine, job, name, campaign_terminal in [
    ('v4',E4,759548,'adaptive-native-corpus-v4-terminal-audit.json',True),
    ('v8',E8,759625,'adaptive-native-corpus-v8-progress-audit-20261028T0726.json',False),
]:
    p = R / ('adaptive-native-corpus-' + version)
    tasks = read(p / 'tasks.json')
    rows = []
    for i, group in enumerate(tasks):
        for task in group:
            q = p / f'group{i}' / task['name'] / 'result.json'
            rc = q.parent.with_suffix('.returncode.txt')
            row = {'name':task['name'],'group':i,'task':task,'result':identity(q) if q.exists() else None,'returncode':identity(rc) if rc.exists() else None,'state':'not_started','passed':False}
            if q.exists():
                d = read(q)
                assert d['source_revision'] == engine
                if rc.exists():
                    row.update(state='terminal',exit_code=int(rc.read_text()),complete=d['complete'],passed=d['passed'] is True and int(rc.read_text()) == 0)
                    row['modes']=[mode_summary(m) for m in d['modes']]
                    assert row['passed'] and all(m['passed'] for m in row['modes'])
                    row['fixed_controls']=[{'rule':c['rule'],'passed':c['passed'],'original_status_equal':c['original_status_equal'],'original_eligibility_equal':c['original_source_and_elastic_eligibility_equal'],'raw_before_accept_errors':c['raw_before_accept_errors']} for c in d['fixed_controls']]
                    assert len(row['fixed_controls']) == 2 and all(c['passed'] is True for c in row['fixed_controls'])
                    row['bound_inputs_unchanged']=d['bound_inputs_unchanged']
                    row['original_model_all_arrays_bitwise_equal']=d['original_model_all_arrays_bitwise_equal']
                    row['mechanical_scope']=d['mechanical_scope']
                    row['whole_frame_qualification']=d['whole_frame_qualification']
                    row['authored_manual_control']=d['authored_manual_control']
                else:
                    row.update(state='timeout_before_mode_completion' if campaign_terminal else 'running_before_mode_completion',complete=d['complete'],passed=False,completed_modes=len(d['modes']))
            rows.append(row)
    assert len(rows)==12 and sum(r['passed'] for r in rows)==9
    write(name, {'schema':'genesis.adaptive-corpus-audit.v1','complete':campaign_terminal,'passed':False,'corpus_complete':False,'source_revision':engine,'job':job,'declared_cases':12,'completed_passed_cases':9,'rows':rows,'source':identity(p/'source.json'),'tasks':identity(p/'tasks.json'),'slurm_state_snapshot':identity(R/'meta/adaptive-corpus-E4-E8-slurm-state-20261028T0726.txt'),'scope':'Only nine terminal cases qualify; manual convex-tip has no completed mode, and the two downstream U controls did not start. Preserve missing/timeout execution negatives; they are not numerical field counterexamples. No full-corpus/default/performance claim.','science_executed_here':False})
