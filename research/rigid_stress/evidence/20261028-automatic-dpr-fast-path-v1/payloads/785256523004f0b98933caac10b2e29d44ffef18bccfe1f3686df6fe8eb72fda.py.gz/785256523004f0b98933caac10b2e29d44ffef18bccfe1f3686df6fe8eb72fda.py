"""Read-only source and original-file preservation audit, using only the standard library."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess


def identity(path):
    content = path.read_bytes()
    return {"path": str(path), "bytes": len(content), "sha256": hashlib.sha256(content).hexdigest()}


def frozen(path, expected):
    head = subprocess.check_output(["git", "-C", str(path), "rev-parse", "HEAD"], text=True).strip()
    changes = subprocess.check_output(["git", "-C", str(path), "diff", "--name-only", "HEAD"], text=True).splitlines()
    return {"path": str(path), "expected_revision": expected, "observed_revision": head,
            "tracked_changes": changes, "passed": head == expected and not changes}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    root = Path(__file__).resolve().parents[1]
    start_path = root / "meta/start-state.json"
    start = json.loads(start_path.read_text())
    baseline_path = Path(start["prior_frozen_source_baseline"])
    baseline = json.loads(baseline_path.read_text())
    original = [{"expected": row, "observed": identity(Path(row["path"]))} for row in start["original_files"]]
    for row in original:
        row["passed"] = row["expected"] == row["observed"]
    previous = [frozen(Path(row["path"]), row["expected_revision"]) for row in baseline["frozen_sources"]]
    source_pins, sources, helpers = {}, [], []
    cached = {}
    for receipt in sorted(root.glob("*/source.json")):
        doc = json.loads(receipt.read_text())
        key = doc["source"], doc["revision"]
        source_pins[key] = None
        mismatches = []
        for row in doc["files"]:
            path = Path(doc["source"]) / row["path"]
            if path not in cached:
                cached[path] = identity(path)
            actual = cached[path]
            if any(actual[k] != row[k] for k in ("bytes", "sha256")):
                mismatches.append({"expected": row, "actual": actual})
        sources.append({"receipt": identity(receipt), "file_count": len(doc["files"]), "mismatches": mismatches, "passed": not mismatches})
        helper_path = receipt.parent / "analysis-files.json"
        if helper_path.is_file():
            files = json.loads(helper_path.read_text())
            mismatches = []
            for row in files:
                path = receipt.parent / "analysis-source" / row["path"]
                actual = identity(path)
                if any(actual[k] != row[k] for k in ("bytes", "sha256")):
                    mismatches.append({"expected": row, "actual": actual})
            helpers.append({"receipt": identity(helper_path), "file_count": len(files), "mismatches": mismatches, "passed": not mismatches})
    current = [frozen(Path(path), revision) for path, revision in sorted(source_pins)]
    measured = "070cb0c96386250dda3a85db703d5705d5c3fccc"
    production_diff = subprocess.check_output(["git", "-C", start["source"], "diff", "--name-only", measured, "--", "genesis", "examples"], text=True).splitlines()
    result = {
        "schema": "genesis.automatic-dpr-final-preservation.v1",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "audit_tool": identity(Path(__file__)), "start": identity(start_path), "baseline": identity(baseline_path),
        "original_files": original, "prior_frozen_sources": previous, "campaign_frozen_sources": current,
        "campaign_source_inventories": sources, "captured_analysis_inventories": helpers,
        "maintained_genesis_examples_diff_from_measured": production_diff,
        "scope": "Read-only byte checks of original twelve files, original source inventories and captured helpers; Git heads/tracked contents for 64 prior and all campaign frozen sources. Runtime numerical success is assessed separately.",
        "passed": len(original) == 12 and len(previous) == 64 and len(current) == 21 and not production_diff
                  and all(row["passed"] for group in (original, previous, current, sources, helpers) for row in group),
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"output": identity(args.output), "passed": result["passed"], "original": len(original), "prior": len(previous), "campaign_sources": len(current), "source_inventories": len(sources), "helper_inventories": len(helpers)}))


if __name__ == "__main__":
    main()
