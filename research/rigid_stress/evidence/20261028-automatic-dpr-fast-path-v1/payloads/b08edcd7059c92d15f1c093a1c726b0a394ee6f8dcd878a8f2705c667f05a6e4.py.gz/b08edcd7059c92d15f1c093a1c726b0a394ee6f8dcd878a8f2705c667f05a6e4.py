"""Parse actual benchmark CLI prefixes without importing or initializing Genesis."""
import argparse,ast,contextlib,hashlib,io,json,os,subprocess,sys
from pathlib import Path
T=Path('/mnt/home/zhaofeng/workspace/Genesis/.worktrees/rigid-stress-recovery')
R=Path('/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/meta')
P=T/'examples/speed_benchmark/rigid_stress.py'
old=subprocess.check_output(['git','-C',str(T),'show','779402b44:examples/speed_benchmark/rigid_stress.py'],text=True)
new=P.read_text()
def parser(source,argv):
 tree=ast.parse(source);main=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='main')
 body=[]
 for node in main.body:
  if isinstance(node,ast.Expr) and isinstance(node.value,ast.Call) and ast.unparse(node.value.func)=='args.output.parent.mkdir':break
  body.append(node)
 body.append(ast.Return(value=ast.Name(id='args',ctx=ast.Load())))
 code=ast.Module(body=[ast.FunctionDef(name='parse',args=main.args,body=body,decorator_list=[])],type_ignores=[]);ast.fix_missing_locations(code)
 ns={'argparse':argparse,'Path':Path,'os':os,'__doc__':'software CLI extraction'}
 exec(compile(code,str(P),'exec'),ns)
 save=sys.argv
 try:
  sys.argv=['benchmark',*argv]
  with contextlib.redirect_stderr(io.StringIO()):return ns['parse']()
 finally:sys.argv=save
rows=[]
def check(name,value):rows.append({'name':name,'passed':bool(value)})
base=['--scope','recovery','--output',str(R/'unused-software-output.json')]
for name,args in [('defaults',[]),('explicit_manual_control',['--radius-model','manual','--pressure-profile','dpr','--pressure-quadrature','edge','--quadrature','16'])]:
 a=vars(parser(old,base+args));b=vars(parser(new,base+args));b.pop('save_module_snapshot');b.pop('module_snapshot');check(name+'_old_actual_parser_values_equal',a==b)
check('producer_flag_accepted',parser(new,base+['--save-module-snapshot',str(R/'fixture')]).save_module_snapshot==R/'fixture')
check('consumer_flag_accepted',parser(new,base+['--module-snapshot',str(R/'fixture')]).module_snapshot==R/'fixture')
for name,args in [('mutually_exclusive',base+['--save-module-snapshot','a','--module-snapshot','b']),('policy_scope',['--scope','policy','--output','x','--module-snapshot','a']),('producer_zero_scene_warmup',base+['--warmup','0','--save-module-snapshot','a']),('moving_trace',base+['--trace','--module-snapshot','a']),('pure_rigid',['--scope','rigid','--output','x','--module-snapshot','a'])]:
 try:parser(new,args)
 except SystemExit as e:check(name+'_rejected',e.code==2)
 else:check(name+'_rejected',False)
check('ordinary_moving_trace_unchanged',parser(new,base+['--trace']).trace is True)
check('no_new_getattr_hasattr',not any(isinstance(x,ast.Call) and isinstance(x.func,ast.Name) and x.func.id in ('getattr','hasattr') for x in ast.walk(ast.parse(new))))
result={'schema':'genesis.module-snapshot-CLI-controls.v1','passed':all(x['passed'] for x in rows),'control_count':len(rows),'rows':rows,'source_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'old_revision':'779402b44','scope':'Actual argparse/validation prefix AST executed with stdlib only, before mkdir/Genesis init. Default and explicit legacy selections equal the old actual parser. No scene, kernels or physics execution.'}
p=R/'module-snapshot-cli-controls-v1.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
raise SystemExit(0 if result['passed'] else 1)
