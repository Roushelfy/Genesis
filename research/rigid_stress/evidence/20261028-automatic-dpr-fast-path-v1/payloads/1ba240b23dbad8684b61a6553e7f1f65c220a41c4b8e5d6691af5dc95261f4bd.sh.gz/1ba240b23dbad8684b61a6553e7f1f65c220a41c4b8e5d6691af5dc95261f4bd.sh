#!/usr/bin/env bash
set -euo pipefail
task_run=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/common-input-profiles-v1/group5
test ! -e "$task_run"
mkdir -p "$task_run"
task_scratch=''
trap 'task_status=$?; printf "%s\n" "$task_status" > "$task_run/returncode.txt"; if test -n "$task_scratch"; then rm -rf -- "$task_scratch"; fi; exit "$task_status"' EXIT
trap 'exit 143' TERM
trap 'exit 130' INT
trap 'exit 129' HUP
task_scratch=$(mktemp -d /tmp/gs-shell-compare.XXXXXX)
task_cache="$task_scratch/cache"
task_tmp="$task_scratch/tmp"
printf "%s\n" "$task_scratch" > "$task_run/node-local-scratch.txt"
df -Pk "$task_scratch" > "$task_run/node-local-filesystem.txt"
mkdir -p "$task_tmp" "$task_cache"
export TMPDIR="$task_tmp" PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export GS_CACHE_FILE_PATH="$task_cache/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/quadrants"
export CUDA_CACHE_PATH="$task_cache/cuda" NUMBA_CACHE_DIR="$task_cache/numba"
export MPLCONFIGDIR="$task_cache/matplotlib"
export QIPC_RTC_CACHE="$task_cache/qipc_rtc"
export PYTHONPATH=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/common-input-profiles-v1/analysis-source:/mnt/home/zhaofeng/workspace/Genesis/.worktrees/automatic-dpr-common-input-v13
cd /mnt/home/zhaofeng/workspace/Genesis/.worktrees/automatic-dpr-common-input-v13
export QD_KERNEL_PROFILER=1
export QD_GRAPH=0
campaign_status=0
export GS_CACHE_FILE_PATH="$task_cache/b25bbab5906964df/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_cache/b25bbab5906964df/quadrants"
if /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m examples.speed_benchmark.rigid_stress --scope profile --envs 8192 --conditions /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261025-gpu-throughput/meta/heterogeneous-conditions.npz --egg-geometry mesh64 --stress-backend volume --box-edge-policy planar --radius-model hertz --pressure-profile hertz --pressure-quadrature angle --quadrature 128 --output-mode full --warmup 730 --steps 10 --repetitions 10 --minimum-seconds 0 --seed 510000 --inverse-precision 64 --history 0 --compact-log --summarize-warmup --source-revision 7a1ea46360f10fc3085b363aab86bdb269652776 --module-snapshot /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/module-snapshot-native-qa-v2/inputs/B8192 --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/common-input-profiles-v1/group5/volume-angle128-B8192-full > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/common-input-profiles-v1/group5/volume-angle128-B8192-full.log 2>&1; then
  printf '%s\n' 0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/common-input-profiles-v1/group5/volume-angle128-B8192-full.returncode.txt
else
  task_exit=$?
  printf '%s\n' "$task_exit" > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261028-automatic-dpr-fast-path/common-input-profiles-v1/group5/volume-angle128-B8192-full.returncode.txt
  campaign_status=1
fi
exit "$campaign_status"
