"""Apply final measured rates and completion text after all original primary rows qualify."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = Path(json.loads((ROOT / "meta/start-state.json").read_text())["source"])
PROJECT = SOURCE / "research/rigid_stress"


def replace(path, old, new):
    text = path.read_text()
    if old not in text:
        raise ValueError(f"Missing expected documentation text in {path}: {old[:100]}")
    path.write_text(text.replace(old, new, 1))


def main():
    audit = json.loads((ROOT / "meta/primary-throughput-v1-terminal-audit.json").read_text())
    summary = json.loads((ROOT / "meta/primary-throughput-summary-v1.json").read_text())
    assert audit["complete"] and audit["passed"] and audit["finished_rows"] == 102
    assert summary["qualified_processes"] == 90 and summary["retained_negative_processes"] == 12
    ratios = {(x["scope"], x["batch"], x["output"]): x["median"] for x in audit["paired_ratios"] if x["comparator"] == "volume_angle128"}
    module = f"{ratios['recovery',8192,'max']:.3f}/{ratios['recovery',8192,'full']:.3f}"
    policy = f"{ratios['policy',8192,'max']:.3f}/{ratios['policy',8192,'full']:.3f}"
    packet = "evidence/20261028-automatic-dpr-fast-path-v1/README.md"
    report = PROJECT / "docs/AUTOMATIC_DPR_FAST_PATH_RESULTS_20261028.md"
    text = report.read_text()
    begin = text.index("The numerical implementation")
    end = text.index("## Recommended configurations")
    text = text[:begin] + (
        "The [requested goal](AUTOMATIC_DPR_FAST_PATH_DEFAULTS_GOAL_20261028.md) is delivered: "
        "qualified selective volume integration, public automatic-radius defaults, complete histories, "
        "matched cost measurements and runnable examples. All102 original primary processes are retained: "
        "90 qualified measurements and12 expected edge16 policy warmup failures. "
        "The [22-clause evidence packet](../" + packet + ") binds each decision to its source and records. "
        "The [progress record](AUTOMATIC_DPR_FAST_PATH_PROGRESS_20261028.md) preserves the diagnostic sequence.\n\n"
    ) + text[end:]
    begin = text.index("All three B4 pairs show")
    end = text.index("## Memory, preparation and remaining cost")
    selected = [x for x in summary["cohorts"] if x["scope"] == "policy" and x["route"] == "volume_adaptive16"]
    totals = {k: sum(x["complete_policy_work_totals"][k] for x in selected) for k in selected[0]["complete_policy_work_totals"]}
    text = text[:begin] + (
        (ROOT / "meta/primary-throughput-tables-v1.md").read_text() + "\n"
        f"At B8192 the paired max/full gains over angle128 are{module} for the module "
        f"and{policy} for complete policy inference. Fixed edge16 is faster on the valid frozen "
        "module frame but all12 complete-policy controls fail their original warmup gate: B4 at "
        "tick607 (failing step606), B8192 at tick222 (failing step221). They have no qualified "
        "rate. All90 qualified measurements have zero invalid environment-steps. The complete "
        "raw repeats, paired ranges against every comparator, setup times and per-environment "
        "work vectors remain in the packet.\n\n"
        f"Across the12 adaptive policy processes, the timed observer records{totals['observed_steps']:,} "
        f"environment-steps and{totals['adaptive_attempted_contacts']:,} source attempts/checks. "
        f"There are{totals['adaptive_repaired_contacts']} repaired sources, "
        f"{totals['adaptive_rejected_contacts']} rejected sources and{totals['adaptive_overflow_replays']} "
        f"overflow replays. Candidate/checker Newton evaluations total{totals['fit_evaluation_sum']}/"
        f"{totals['adaptive_checker_fit_evaluation_sum']}. These actual low-cost trajectories do not "
        "replace the nonlinear/refinement corpus and authored switching controls. The source-local "
        "admission check still runs for each attempt.\n\n"
    ) + text[end:]
    text = text.replace("Final packaging and the22-clause delivery ledger remain pending the primary run.",
        "The compact packet retains every original primary benchmark/result JSON, all22 requirement "
        "decisions, protocol/source receipts and retained failures. Complete histories and fields remain "
        "on data with their recorded hashes. `meta/primary-throughput-v1-terminal-audit.json` and "
        "`meta/primary-throughput-summary-v1.json` can be decoded from the packet index.\n\n"
        "To repeat the primary audit, use `python -m research.rigid_stress.qipc_comparison.audit_dpr_fast_primary` "
        "with `--run <run-root>/primary-throughput-v1`, `--manifest <run-root>/meta/primary-throughput-v4-tasks.json`, "
        "`--source <fresh-checkout-at-070cb0c96>` and a fresh `--output` path. It reads existing terminal "
        "artifacts using the standard library. Scientific reruns use the recorded task arguments and "
        "captured worker inside the declared Slurm environment, with fresh data outputs.")
    report.write_text(text)

    goal = PROJECT / "GOAL.md"
    old = goal.read_text()
    goal.write_text("# Native rigid stress recovery: automatic DPR fast path and defaults\n\n"
        "**Completed user goal, 2026-10-28:** the [automatic DPR goal](docs/AUTOMATIC_DPR_FAST_PATH_DEFAULTS_GOAL_20261028.md) "
        "has implemented public defaults, native selective integration, full-field/history qualification, "
        "matched performance/memory evidence and tested public examples. Read the "
        "[results](docs/AUTOMATIC_DPR_FAST_PATH_RESULTS_20261028.md), "
        "[running guide](docs/RUNNING_AUTOMATIC_DPR.md) and [22-clause packet](" + packet + ").\n\n"
        "Ordinary volume DPR uses pressure/patch/Hertz/Hertz and adaptive angular16 with independent "
        "checking and selective64/128 repair. Original fit/wrench/K/lifecycle gates remain. Volume "
        "remains the backend default and Q4 remains shell loading default; the measured shell recipe "
        "explicitly selects planar k32/q10/radial/blocks/cap128, FP64/history0 and GraphOff. "
        "Sharp-box planar curvature is an explicit surrogate.\n\n"
        f"Measured engine is070cb0c96386250dda3a85db703d5705d5c3fccc. B8192 max/full module gains "
        f"over angle128 are{module}; complete policy-inference gains are{policy}. All102 original "
        "primary processes are accounted for, including12 retained edge16 warmup failures. Final "
        "eight1200-step B4/B64 scripted/policy max/full histories pass; the separate41-point path "
        "exercises eight switches. Final48 default/lifecycle tests and20 loaded test executions pass.\n\n"
        "Admission is empirically qualified on the declared finite corpus, not a universal spatial "
        "bound. Old strict load-comparison negatives, extra adaptive memory and sharp-edge/continuum "
        "uncertainty remain explicit. Original12 unfinished files,64 prior and21 campaign frozen "
        "sources remain preserved. This closes the requested goal; unchanged prior campaigns are "
        "not new implementation prerequisites.\n\n" + old[old.index("## Previous delivery: planar loading DPR optimization"):])

    agents = PROJECT / "AGENTS.md"
    old = agents.read_text()
    agents.write_text("# Working on native rigid stress recovery\n\n"
        "**Completed user goal, 2026-10-28:** [automatic DPR fast path/defaults](docs/AUTOMATIC_DPR_FAST_PATH_DEFAULTS_GOAL_20261028.md). "
        "Read [GOAL.md](GOAL.md), the [results](docs/AUTOMATIC_DPR_FAST_PATH_RESULTS_20261028.md) "
        "and [22-clause packet](" + packet + ").\n\n"
        "Keep ordinary pressure/patch/Hertz/Hertz defaults and volume adaptive16 with independent "
        "source-node checking and selective64/128 repair. Preserve original fit1e-9, source1e-8, "
        "K/material/lifecycle checks, source-local replacement, serial/overflow paths and uniform "
        "cooperative Newton decisions. Explicit manual/legacy, fixed quadrature and SCR contexts "
        "remain supported. Volume and shell Q4 stay public backend/loading defaults; use the "
        "documented planar k32 recipe explicitly for the measured shell workload.\n\n"
        f"Engine070cb0c96 has all102 primary receipts (90 qualified,12 edge16 negatives), final "
        f"eight complete histories,48 default/lifecycle and20 loaded test executions. B8192 "
        f"max/full gains over angle128 are{module} module and{policy} complete policy inference. "
        "Retain the empirical admission scope, authored-only switching evidence, extra memory, "
        "old strict load negatives and continuum sharp-edge limitations. Preserve original12 "
        "files,64 prior and21 new frozen sources, all raw failures and the data-side run. "
        "Do not restart unchanged diagnosis, broad convergence or prior closed campaigns without "
        "new user scope or a concrete changed-workload reason. Standing policies below apply.\n\n" + old[old.index("## Previous completed planar goal"):])

    readme = PROJECT / "README.md"
    old = readme.read_text()
    begin = old.index("## Active: automatic DPR")
    end = old.index("## Delivered: planar loading")
    readme.write_text(old[:begin] + "## Delivered: automatic DPR fast path, defaults and examples (2026-10-28)\n\n"
        "Public Options and `.dpr()` now use pressure/patch/Hertz/Hertz. Ordinary volume loading "
        "selects adaptive angular16 with independent checking and selective64/128 repair. "
        "Explicit manual/legacy, fixed quadrature and SCR remain available; volume and shell Q4 "
        "remain the backend/loading defaults.\n\n"
        f"All102 primary processes are retained:90 qualified measurements and12 original edge16 "
        f"policy failures. B8192 max/full gains over angle128 are{module} module and{policy} "
        "complete policy inference. Final eight1200-step histories,48 default/lifecycle and20 "
        "loaded test executions pass. Extra adaptive memory, old strict load negatives and "
        "finite-corpus/sharp-edge limits remain explicit.\n\n"
        "Read the [results](docs/AUTOMATIC_DPR_FAST_PATH_RESULTS_20261028.md), "
        "[short volume/shell examples](docs/RUNNING_AUTOMATIC_DPR.md) and "
        "[22-clause packet](" + packet + "). Measured source is070cb0c96; later delivery "
        "commits preserve its engine. Previous deliveries retain their scope.\n\n" + old[end:])

    api = PROJECT / "docs/NATIVE_API.md"
    replace(api, "The active\n[fast-path study](AUTOMATIC_DPR_FAST_PATH_PROGRESS_20261028.md) separately evaluates", "The completed\n[fast-path study](AUTOMATIC_DPR_FAST_PATH_RESULTS_20261028.md) separately evaluates")
    replace(api, "Final default\nworkflow and matched cost verification remain tracked by the active goal.", "Final default\nworkflow, paired timing and memory are recorded in the fast-path report.")
    running = PROJECT / "docs/RUNNING_AUTOMATIC_DPR.md"
    replace(running, "最终示例、完整历史和配对计时状态见[执行记录](AUTOMATIC_DPR_FAST_PATH_PROGRESS_20261028.md)，当前目标仍未关闭。", "公共示例、完整历史及三组配对计时均已完成，精度、速度和显存取舍见[结果报告](AUTOMATIC_DPR_FAST_PATH_RESULTS_20261028.md)。")
    progress = PROJECT / "docs/AUTOMATIC_DPR_FAST_PATH_PROGRESS_20261028.md"
    replace(progress, "remains active.", "is complete; see the [final results](AUTOMATIC_DPR_FAST_PATH_RESULTS_20261028.md).")
    replace(progress, "The primary job760098 and final evidence/recommendation\ndelivery are still open. Completed histories/public examples are not pending.", "All102 original primary processes are now terminal and audited:90 qualified\nmeasurements and12 retained edge16 policy negatives. The final report and22-clause\npacket close the requested implementation/evidence goal.")
    replace(progress, "Matched cost qualification remains\nin progress.", "Matched cost qualification is complete.")
    replace(progress, "## Final public verification and remaining delivery", "## Final public verification and delivery")
    location = SOURCE / "DATA_LOCATION.md"
    replace(location, "The active automatic DPR fast-path/defaults phase", "The completed automatic DPR fast-path/defaults phase")
    replace(location, "No data or active-environment migration is performed.", "No data or active-environment migration is performed. The compact publication\npacket is `research/rigid_stress/evidence/20261028-automatic-dpr-fast-path-v1/`;\ncomplete arrays and logs remain on data. All12 original files,64 prior and21\ncampaign frozen sources and69 source/helper inventories remain preserved.")
    print(json.dumps({"documentation_updated": True, "B8192_module_gains": module, "B8192_policy_gains": policy, "adaptive_policy_totals": totals}))


if __name__ == "__main__":
    main()
