"""Independently check packet hashes and recompute every paired timing from raw rows.

Standard library only. Default verification needs no external run files. Optional
--check-originals additionally compares all original primary bytes and metadata.
This checks engineering receipts, not numerical or spatial fields anew.
"""

import argparse
import gzip
import hashlib
import json
import math
import statistics
from datetime import datetime, timezone
from pathlib import Path


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def exact(a, b):
    if type(a) is not type(b):
        return False
    if isinstance(a, float):
        return (math.isnan(a) and math.isnan(b)) or a.hex() == b.hex()
    if isinstance(a, dict):
        return a.keys() == b.keys() and all(exact(a[k], b[k]) for k in a)
    if isinstance(a, list):
        return len(a) == len(b) and all(exact(x, y) for x, y in zip(a, b))
    return a == b



MAX_PRIMARY_TASK_BYTES = 256 * 1024 * 1024
MAX_PRIMARY_HEADER_BYTES = 16 * 1024 * 1024
MAX_PRIMARY_LINE_BYTES = 8 * 1024 * 1024


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def _finite_json(raw):
    def reject(value):
        raise ValueError(f"Nonfinite JSON constant: {value}")
    return json.loads(raw, object_pairs_hook=_unique_object, parse_constant=reject)


def stream_primary_json(path, expected_identity, on_task):
    """Read the frozen indent=2 full JSON, retaining at most one decoded task.

    Exact line framing is deliberate and fail closed: root tasks is an array
    of dictionaries at indentation four; nested JSON is decoded normally.
    Every original decompressed byte participates in the full-file identity.
    The small root object, including all blocks/cohorts/issues, is decoded only
    after EOF/CRC, syntax and full hash/size checks. No compact view is used.
    """
    header, task = bytearray(), bytearray()
    digest = hashlib.sha256()
    size, count, largest_task = 0, 0, 0
    state, next_kind = "prefix", "first"
    with gzip.open(path, "rb") as stream:
        while True:
            line = stream.readline(MAX_PRIMARY_LINE_BYTES + 1)
            if not line:
                break
            if len(line) > MAX_PRIMARY_LINE_BYTES:
                raise ValueError("Full primary JSON line exceeds bounded read limit")
            digest.update(line)
            size += len(line)
            stripped = line.rstrip(b"\r\n")
            if state == "prefix":
                header.extend(line)
                if stripped == b'  "tasks": [':
                    state = "between"
            elif state == "between":
                if stripped in (b"  ]", b"  ],"):
                    if next_kind not in ("first", "close"):
                        raise ValueError("Trailing comma in primary task array")
                    header.extend(line)
                    state = "suffix"
                elif stripped == b"    {" and next_kind in ("first", "task"):
                    task.extend(line)
                    state = "task"
                else:
                    raise ValueError("Unexpected primary task array framing")
            elif state == "task":
                task.extend(line)
                if len(task) > MAX_PRIMARY_TASK_BYTES:
                    raise ValueError("Primary task exceeds bounded decode limit")
                if stripped in (b"    }", b"    },"):
                    comma = stripped.endswith(b",")
                    raw = task.rstrip()
                    if comma:
                        raw = raw[:-1]
                    document = _finite_json(raw)
                    if not isinstance(document, dict):
                        raise ValueError("Primary task must be a JSON dictionary")
                    on_task(document)
                    count += 1
                    largest_task = max(largest_task, len(task))
                    task.clear()
                    del raw, document
                    state, next_kind = "between", "task" if comma else "close"
            else:
                header.extend(line)
            if len(header) > MAX_PRIMARY_HEADER_BYTES:
                raise ValueError("Primary root metadata exceeds bounded decode limit")
    if state != "suffix":
        raise ValueError("Missing or truncated indent=2 root primary tasks array")
    observed = {"bytes": size, "sha256": digest.hexdigest()}
    if any(observed[key] != expected_identity[key] for key in observed):
        raise ValueError(f"Full primary decompressed identity mismatch: {observed}")
    document = _finite_json(header)
    if not isinstance(document, dict) or document.get("tasks") != []:
        raise ValueError("Invalid primary root object/tasks member")
    return document, {**observed, "tasks": count, "max_task_bytes": largest_task,
                      "root_metadata_bytes": len(header), "bounded_task_limit_bytes": MAX_PRIMARY_TASK_BYTES}



def read_packet_index(root):
    """Decode either the legacy direct index or the lossless planar gzip reference."""
    content = (root / "index.json").read_bytes()
    reference = _finite_json(content)
    if reference.get("schema") != "genesis.planar-evidence-index-reference.v1":
        return reference, {"encoding": "json", "bytes": len(content), "sha256": sha(content)}
    assert reference["encoding"] == "gzip" and reference["path"] == "index.json.gz"
    compressed = (root / reference["path"]).read_bytes()
    assert len(compressed) == reference["compressed_bytes"] and sha(compressed) == reference["compressed_sha256"]
    assert 0 < reference["decompressed_bytes"] <= 128 * 1024 * 1024
    with gzip.open(root / reference["path"], "rb") as stream:
        decoded = stream.read(128 * 1024 * 1024 + 1)
    assert len(decoded) == reference["decompressed_bytes"] and sha(decoded) == reference["decompressed_sha256"]
    index = _finite_json(decoded)
    assert isinstance(index, dict) and index.get("schema") == "genesis.planar-compact-evidence.v1"
    return index, {
        "encoding": "gzip", "path": reference["path"],
        "reference_bytes": len(content), "reference_sha256": sha(content),
        "compressed_bytes": len(compressed), "compressed_sha256": sha(compressed),
        "decompressed_bytes": len(decoded), "decompressed_sha256": sha(decoded),
    }

def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument("--packet", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--check-originals", action="store_true")
    args = parser.parse_args()
    root = args.packet.resolve()
    assert not args.output.resolve().is_relative_to(root), "Verification receipt must stay outside the hashed packet"
    index, index_encoding = read_packet_index(root)
    files = [p for p in root.rglob("*") if p.is_file()]
    size = sum(p.stat().st_size for p in files)
    assert size <= 10 * 1024 * 1024
    listed = set()
    for line in (root / "SHA256SUMS").read_text().splitlines():
        digest, relative = line.split("  ", 1)
        target = (root / relative).resolve()
        assert target.is_relative_to(root) and target.is_file()
        assert sha(target.read_bytes()) == digest
        listed.add(relative)
    assert listed == {str(p.relative_to(root)) for p in files if p.name != "SHA256SUMS"}
    for relative, identity in index["payloads"].items():
        raw = (root / relative).read_bytes()
        assert len(raw) == identity["bytes"] and sha(raw) == identity["sha256"]
    inventory = [json.loads(line) for line in gzip.decompress((root / "external-artifacts.jsonl.gz").read_bytes()).splitlines()]
    inventory_by_path = {a["path"]: a for a in inventory}
    assert len(inventory_by_path) == len(inventory)
    primary_tasks = {t["id"]: t for t in index["tasks"] if t["id"].startswith("primary-paired-v19/")}
    assert len(primary_tasks) == 168
    assert all(t["execution_status"] == "exit_zero" and t["task_payload_collected"] is True for t in primary_tasks.values())

    def retained_json(name, compressed=False):
        matches = [a for a in inventory if a["path"].endswith("/meta/" + name)]
        assert len(matches) == 1, (name, len(matches))
        artifact = matches[0]
        candidates = artifact["retained_payloads"]
        assert len(candidates) == 1, (name, candidates)
        raw = (root / candidates[0]).read_bytes()
        # .json.gz metadata is retained as the original compressed binary;
        # ordinary .json metadata is gzip-compressed by the packet writer.
        decoded = gzip.decompress(raw)
        if compressed:
            assert sha(raw) == artifact["sha256"]
            original_name = name.removesuffix(".gz")
            original = next(a for a in inventory if a["path"].endswith("/meta/" + original_name))
            assert len(decoded) == original["bytes"] and sha(decoded) == original["sha256"]
        else:
            assert len(decoded) == artifact["bytes"] and sha(decoded) == artifact["sha256"]
        return json.loads(decoded)

    memory = retained_json("final-memory-summary-v19.json.gz", True)
    profile = retained_json("final-profile-summary-v19.json.gz", True)
    inputs = retained_json("reproduction-inputs-v19.json")
    expected_inputs = {
        "timing_small4": "ab451473db350152f812f095c64e8595a558a5ea07e4d884ba8b55d7680ff9a8",
        "accuracy_heterogeneous64": "db60d16e02b41f8850bf255052939831ef25cd2a07f07c1fb052eb8efe4f1310",
    }
    assert inputs["passed"] is True and {r["role"] for r in inputs["inputs"]} == expected_inputs.keys()
    for row in inputs["inputs"]:
        assert row["sha256"] == expected_inputs[row["role"]] and row["byte_exact"] is True
        artifact = inventory_by_path[row["retained_copy"]]
        assert len(artifact["retained_payloads"]) == 1
        raw = (root / artifact["retained_payloads"][0]).read_bytes()
        assert len(raw) == row["bytes"] and sha(raw) == row["sha256"]
    assert memory["overall_qualified"] is True and memory["qualified_workers"] == 28
    assert profile["complete"] is True and profile["passed"] is True and profile["row_count"] == 14
    ledger = json.loads((root / "requirements-ledger.json").read_bytes())
    assert ledger["qualification_receipts_complete"] is True
    assert len(ledger["requirements"]) == 29 and all(not q["pending_evidence"] for q in ledger["requirements"])

    raw_rows = {}
    raw_paths = [p for p, identity in index["payloads"].items() if identity["category"] == "primary-raw-measurements"]
    assert len(raw_paths) == 168
    originals_checked = 0
    for relative in raw_paths:
        record = json.loads(gzip.decompress((root / relative).read_bytes()))
        assert record["schema"] == "genesis.planar-primary-benchmark-rows.v1"
        assert record["qualification_assessed"] is False and record["terminal_returncode"] == 0
        task_id = record["task_id"]
        assert task_id not in raw_rows and task_id in primary_tasks
        original_identity = inventory_by_path[record["source"]["path"]]
        assert all(exact(record["source"][k], original_identity[k]) for k in ["path", "bytes", "sha256"])
        raw_rows[task_id] = relative
        if args.check_originals:
            raw = Path(record["source"]["path"]).read_bytes()
            assert sha(raw) == record["source"]["sha256"] and len(raw) == record["source"]["bytes"]
            original = json.loads(raw)
            assert exact(original["repeats"], record["repeats"])
            excluded = set(record["excluded_top_level_fields_retained_externally"])
            assert exact({k: v for k, v in original.items() if k != "repeats" and k not in excluded}, record["benchmark_metadata"])
            originals_checked += 1

    times = {}
    physical = {}
    pids = set()
    seen_tasks = set()

    def compare_primary_task(task):
        spec = task["specification"]
        task_id = f"primary-paired-v19/group{spec['group']}/{spec['name']}"
        assert task_id not in seen_tasks and task_id in raw_rows
        seen_tasks.add(task_id)
        raw = json.loads(gzip.decompress((root / raw_rows[task_id]).read_bytes()))
        assert raw["source"]["sha256"] == task["result_file"]["sha256"]
        assert raw["source"]["path"] == task["result_file"]["path"]
        assert raw["source"]["bytes"] == task["result_file"]["bytes"]
        assert exact(raw["repeats"], task["timed_repetitions"])
        assert task["issues"] == [] and task["returncode"] == 0
        meta = raw["benchmark_metadata"]
        assert meta["source_revision"] == "6dedc79579ac0d113e4baac26eb538bcf51ca57d"
        assert meta["conditions_sha256"] == expected_inputs["timing_small4"]
        assert meta["policy"]["weights_sha256"] == "37952a933b9ceb5bfcd86473abed687ee3fc7bce9409385f1567ef0bd4f7aa64"
        assert meta["cuda_graphs_enabled"] is False
        pid = (meta["host"], meta["slurm_job_id"], meta["pid"])
        assert pid not in pids
        pids.add(pid)
        assert len(raw["repeats"]) == 1
        repeat = raw["repeats"][0]
        assert repeat["steps"] == 600 and repeat["invalid_environment_steps"] == 0 and repeat["scatter_overflow_calls"] == 0
        assert math.isfinite(repeat["seconds"]) and repeat["seconds"] > 0
        failures = repeat["failed_steps_per_environment"]
        assert failures is None or (len(failures) == spec["batch"] and all(x == 0 for x in failures))
        routes = repeat["planar_routes"]
        if spec["variant"] == "planar32":
            assert routes["full_interval_counts_available"] is True and routes["environment_resets_inside_timer"] == 0
            delta = routes["per_environment_delta"]
            assert sum(delta["fallback_contacts"]) == 0 and sum(delta["overflow_steps"]) == 0
        key = (spec["group"], spec["block"])
        times.setdefault(key, {})[spec["variant"]] = repeat["seconds"]
        if spec["scope"] == "recovery":
            identity = meta["recovery_snapshot_check"]["physical_source_identity"]
            identity = {k: identity[k] for k in ["sha256", "shape", "dtype", "columns"]}
            if key in physical:
                assert exact(physical[key], identity)
            physical[key] = identity

    summaries = [a for a in inventory if a["path"].endswith("/meta/primary-summary-v19.json.gz")]
    originals = [a for a in inventory if a["path"].endswith("/meta/primary-summary-v19.json")]
    assert len(summaries) == len(originals) == 1
    artifact = summaries[0]
    assert len(artifact["retained_payloads"]) == 1
    primary_path = root / artifact["retained_payloads"][0]
    assert primary_path.stat().st_size == artifact["bytes"] and sha(primary_path.read_bytes()) == artifact["sha256"]
    primary, primary_stream = stream_primary_json(primary_path, originals[0], compare_primary_task)
    assert primary_stream["tasks"] == 168 and seen_tasks == set(primary_tasks) == set(raw_rows)
    assert primary["primary_qualified"] is True and primary["diagnostic_only"] is False
    assert primary["metadata_checks_passed"] is True and primary["issues"] == []
    assert len(primary["blocks"]) == 48 and len(primary["cohorts"]) == 16

    for block in primary["blocks"]:
        values = times[(block["group"], block["block"])]
        assert exact(values, block["raw_elapsed_seconds_median_of_internal_repeats"])
        assert block["primary_qualified"] is True
        for ratio, value in block["qualified_elapsed_ratios_numerator_over_denominator"].items():
            numerator, denominator = ratio.split("/")
            assert exact(values[numerator] / values[denominator], value)
    ratio_count = 0
    for cohort in primary["cohorts"]:
        blocks = [b for b in primary["blocks"] if b["group"] == cohort["group"]]
        assert len(blocks) == 3
        for ratio in cohort["ratios"]:
            numerator, denominator = ratio["elapsed_ratio_numerator_over_denominator"].split("/")
            values = [times[(b["group"], b["block"])][numerator] / times[(b["group"], b["block"])][denominator] for b in blocks]
            assert ratio["all_three_blocks_qualified"] is True
            assert exact(statistics.median(values), ratio["qualified_median"])
            assert exact([min(values), max(values)], ratio["qualified_range"])
            ratio_count += 1
    result = {
        "schema": "genesis.planar-final-packet-independent-audit.v1",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "packet": str(root), "passed": True, "packet_bytes": size,
        "packet_index_sha256": sha((root / "index.json").read_bytes()),
        "packet_index_encoding": index_encoding,
        "packet_SHA256SUMS_sha256": sha((root / "SHA256SUMS").read_bytes()),
        "hashed_files": len(listed), "original_primary_rows_retained_losslessly": 168,
        "blocks_recomputed_from_raw_rows": 48, "cohorts_recomputed_from_raw_rows": 16,
        "paired_ratio_summaries_recomputed": ratio_count,
        "external_originals_additionally_checked": originals_checked,
        "compressed_full_primary_memory_profile_summaries_exact": True,
        "full_primary_streaming": primary_stream,
        "exact_reproduction_condition_inputs_retained": len(expected_inputs),
        "scope": "Offline packet/hash/raw-timing identity and ratio audit. Prior scientific qualification is retained, not recomputed. Device sampled peaks use recorded summaries; full external NVIDIA polling logs are not required inside this packet.",
        "verifier_sha256": sha(Path(__file__).read_bytes()),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
