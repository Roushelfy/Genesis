"""Read-only final source preservation refresh; standard library only."""
import argparse
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

M = Path(__file__).resolve().parent
T = Path('/mnt/home/zhaofeng/workspace/Genesis/.worktrees/rigid-stress-recovery')

def identity(path):
    p = Path(path)
    raw = p.read_bytes()
    return dict(path=str(p), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def git(*args, cwd=T):
    return subprocess.check_output(['git', '-C', str(cwd), *args], text=True).strip()

def main():
    ap = argparse.ArgumentParser(__doc__)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    old = json.loads((M/'preservation-preflight-v19.json').read_text())
    owned = json.loads((M/'owned-source-hash-preflight-v19.json').read_text())
    originals = []
    for row in old['original_files']:
        observed = identity(row['observed']['path'])
        originals.append(dict(expected_sha256=row['expected_sha256'], observed=observed,
                              passed=observed['sha256']==row['expected_sha256']))
    sources = []
    for scope in ['old_frozen_sources', 'new_frozen_sources']:
        for row in old[scope]:
            revision = git('rev-parse', 'HEAD', cwd=row['path'])
            changes = git('diff', '--no-ext-diff', '--name-only', 'HEAD', cwd=row['path']).splitlines()
            sources.append(dict(scope=scope, path=row['path'], expected_revision=row['expected_revision'],
                                observed_revision=revision, tracked_changes=changes,
                                passed=revision==row['expected_revision'] and not changes))
    files=[]
    for row in owned['files']:
        observed=identity(row['expected']['path'])
        files.append(dict(expected=row['expected'], observed=observed, passed=observed==row['expected']))
    assert len(originals)==12 and len(sources)==64 and len(files)==36
    passed=all(r['passed'] for r in originals+sources+files)
    result=dict(schema='genesis.planar-delivery-preservation.v19', created_utc=datetime.now(timezone.utc).isoformat(),
                source=str(T), observed_HEAD=git('rev-parse','HEAD'), passed=passed,
                baseline=identity(M/'preservation-preflight-v19.json'), owned_baseline=identity(M/'owned-source-hash-preflight-v19.json'),
                original_files=originals, frozen_sources=sources, owned_python=files,
                status=git('status','--short'),
                scope='Read-only12original/33old/31new/36owned identity refresh; no scientific execution or runtime data migration.')
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(output=str(args.output), passed=passed, originals=len(originals), frozen=len(sources), owned=len(files))))
    if not passed:
        raise SystemExit(1)

if __name__=='__main__':
    main()
