"""Check every ledger artifact identity and exact small nested receipt payload."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    parser=argparse.ArgumentParser(__doc__)
    parser.add_argument('--packet', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args=parser.parse_args()
    packet=args.packet.resolve()
    assert not args.output.resolve().is_relative_to(packet)
    inventory=[json.loads(line) for line in gzip.decompress((packet/'external-artifacts.jsonl.gz').read_bytes()).splitlines()]
    artifacts={row['path']:row for row in inventory}
    index=json.loads((packet/'index.json').read_text())
    index_encoding='json'
    if index.get('schema')=='genesis.planar-evidence-index-reference.v1':
        reference=index
        assert reference['encoding']=='gzip' and reference['path']=='index.json.gz'
        compressed=(packet/reference['path']).read_bytes()
        assert len(compressed)==reference['compressed_bytes'] and digest(compressed)==reference['compressed_sha256']
        assert 0 < reference['decompressed_bytes'] <= 128*1024*1024
        with gzip.open(packet/reference['path'],'rb') as stream:
            decoded=stream.read(128*1024*1024+1)
        assert len(decoded)==reference['decompressed_bytes'] and digest(decoded)==reference['decompressed_sha256']
        index=json.loads(decoded)
        index_encoding='gzip'
    ledger=json.loads((packet/'requirements-ledger.json').read_text())
    maprows=[row for row in inventory if row['path'].endswith('/meta/retained-ledger-receipts-v19.json')]
    assert len(maprows)==1
    def decoded_artifact(row):
        assert len(row['retained_payloads'])==1
        payload=row['retained_payloads'][0]
        raw=(packet/payload).read_bytes()
        assert payload in index['payloads'] and digest(raw)==index['payloads'][payload]['sha256']
        decoded=gzip.decompress(raw) if payload.endswith('.gz') else raw
        assert len(decoded)==row['bytes'] and digest(decoded)==row['sha256']
        return decoded
    mapping=json.loads(decoded_artifact(maprows[0]))
    assert mapping['passed'] is True
    copies={row['original']['path']:row for row in mapping['receipts']}
    for row in copies.values():
        original,copy=row['original'],row['copy']
        assert row['byte_exact'] is True
        assert original['bytes']==copy['bytes'] and original['sha256']==copy['sha256']
        assert all(artifacts[copy['path']][k]==copy[k] for k in ('path','bytes','sha256'))
        decoded_artifact(artifacts[copy['path']])
    found={}
    def walk(value):
        if isinstance(value,dict):
            if set(('path','bytes','sha256'))<=value.keys():
                found[value['path']]={k:value[k] for k in ('path','bytes','sha256')}
            for v in value.values(): walk(v)
        elif isinstance(value,list):
            for v in value: walk(v)
    walk(ledger)
    checks=[]
    for path,identity in found.items():
        observed=artifacts.get(path) or copies.get(path,{}).get('original')
        assert observed is not None, path
        assert all(observed[k]==identity[k] for k in ('path','bytes','sha256')),path
        checks.append({'identity':identity,'recorded_in_external_inventory':path in artifacts,'exact_copy_retained':path in copies})
    result={'schema':'genesis.planar-ledger-artifact-retention-audit.v19','passed':True,
            'packet_index_sha256':digest((packet/'index.json').read_bytes()),
            'packet_SHA256SUMS_sha256':digest((packet/'SHA256SUMS').read_bytes()),
            'index_encoding':index_encoding,
            'verifier_sha256':digest(Path(__file__).read_bytes()),
            'ledger_artifact_identities_checked':len(checks),'exact_small_receipts_retained':len(copies),
            'copies':list(copies.values()),'checks':checks,
            'scope':'Identity/retention only. Full primary/memory/profile gzip and raw timing checks are performed by the separate independent packet verifier. Other large scientific data remain externally hashed as declared.'}
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('checks','copies')}))

if __name__=='__main__':
    main()
