"""Wait for the fixed final rollout, validate metadata, then queue CPU figure QA."""
import json
import subprocess
import time
from pathlib import Path

root = Path('/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261017-pressure-comparison')
while True:
    result = subprocess.check_output(['sacct', '-j', '725615_1', '-X', '-n', '-P', '-o', 'State,ExitCode'], text=True).strip()
    if result:
        state, code = result.split('|')[:2]
        if state in {'COMPLETED', 'FAILED', 'CANCELLED', 'TIMEOUT', 'OUT_OF_MEMORY', 'NODE_FAIL'}:
            assert state == 'COMPLETED' and code == '0:0', result
            break
    time.sleep(30)
subprocess.run(['/usr/bin/python3', str(root/'meta/summarize_pressure_comparison-v6.py'), '--root', str(root), '--output', str(root/'metadata-final-v1')], check=True)
subprocess.run(['/usr/bin/python3', str(root/'plot-source-v4/audit_pressure_comparison.py'), '--root', str(root), '--metadata', str(root/'metadata-final-v1/comparison.json'), '--output', str(root/'completion-audit-v1.json')], check=True)
subprocess.run(['/usr/bin/python3', str(root/'plot-source-v4/build_tables.py'), '--metadata', str(root/'metadata-final-v1/comparison.json'), '--output', str(root/'report-tables-v1.md')], check=True)
submissions = []
for stage in ['render', 'export']:
    command = ['sbatch', '--parsable', '--partition=cpu', '--cpus-per-task=2', '--mem=8G', '--time=00:10:00', '--array=0-0', '--output='+str(root/('meta/'+stage+'-final-v1-%A_%a.log'))]
    if submissions:
        command += ['--dependency=afterok:'+submissions[-1]['job_id']]
    command.append(str(root/('meta/'+stage+'-final-v1.sh')))
    result = subprocess.run(command, check=True, text=True, capture_output=True)
    job = result.stdout.strip().split(';')[0]
    assert job.isdigit(), result.stdout
    submissions.append({'stage':stage, 'job_id':job, 'argv':command, 'stdout':result.stdout, 'stderr':result.stderr})
    (root/'meta/final-figure-submissions-v1.json').write_text(json.dumps(submissions, indent=2)+'\n')
    print(stage, job, flush=True)
