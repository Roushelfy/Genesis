import torch
x = torch.ones(1048576, device="cuda")
y = x * 2
torch.cuda.synchronize()
assert y[0].item() == 2
