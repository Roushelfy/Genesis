"""Preserve the known generated-bank incompatibility without assigning a rollout rate."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

import genesis as gs
from examples.rigid.franka_egg_stress import FrankaEgg
from genesis.utils.misc import qd_to_numpy

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
args.output.mkdir()
gs.init(backend=gs.cuda, precision="64", logging_level="warning")
workload = FrankaEgg(8, varied=True, seed=510000, contact_model="intrinsic", intrinsic_load_partition="body_source_prior", egg_geometry="mesh64", use_gjk_collision=False, enable_contact_patch=False)
entry = workload.scene.rigid_solver.stress_recovery.links[0]
try:
    for _ in range(600):
        workload.step()
        workload.scene.rigid_solver.check_errno()
except gs.GenesisException as error:
    if "Native stress contact recovery rejected a load" not in str(error):
        raise
    failure = entry.intrinsic.failure
    status = qd_to_numpy(failure.status)
    forces = qd_to_numpy(entry.contacts.force, transpose=True)
    valid = qd_to_numpy(entry.contacts.valid, transpose=True)
    target = qd_to_numpy(failure.target_force)
    moment = qd_to_numpy(failure.target_moment)
    failed = np.flatnonzero(status)
    np.savez_compressed(args.output / "rejected-input.npz", valid=valid, position=qd_to_numpy(entry.contacts.position, transpose=True), force=forces, normal=qd_to_numpy(entry.contacts.normal, transpose=True), radius=qd_to_numpy(entry.contacts.radius, transpose=True), friction=qd_to_numpy(entry.contacts.friction, transpose=True), source_witness=qd_to_numpy(entry.intrinsic.raw_sources.witness, transpose=True), source_free_moment=qd_to_numpy(entry.intrinsic.raw_sources.free_moment, transpose=True), frame_position=qd_to_numpy(entry.contacts.frame_position), frame_quaternion=qd_to_numpy(entry.contacts.frame_quaternion), failure_status=status, failure_contact=qd_to_numpy(failure.contact), failure_group_count=qd_to_numpy(failure.group_count), failure_position=qd_to_numpy(failure.position), failure_anchor=qd_to_numpy(failure.anchor), failure_force=qd_to_numpy(failure.force), failure_target_force=target, failure_target_moment=moment)
    rows = [{"env": int(index), "status": int(status[index]), "source_count": int(qd_to_numpy(failure.group_count)[index]), "target_force_N": target[index].tolist(), "target_moment_about_first_source_Nm": moment[index].tolist(), "net_force_fraction_of_source_norm_sum": float(np.linalg.norm(target[index]) / np.linalg.norm(forces[index, valid[index]], axis=1).sum())} for index in failed]
    result = {"requested_steps": 600, "rejected_at_tick": workload.tick, "successful_full_rollout": False, "successful_rollout_rate": None, "classification": "continuous_load_incompatible" if np.isin(status[failed], [35, 36]).all() else "native_load_rejected", "failures": rows, "error": str(error), "stress_options": entry.options.model_dump(mode="json"), "snapshot_manifest_sha256": hashlib.sha256(Path("snapshot-files.sha256").read_bytes()).hexdigest()}
    (args.output / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)
else:
    (args.output / "summary.json").write_text(json.dumps({"requested_steps":600,"successful_full_rollout":True,"classification":"old_failure_not_reproduced","stress_options":entry.options.model_dump(mode="json")}, indent=2)+'\n')
