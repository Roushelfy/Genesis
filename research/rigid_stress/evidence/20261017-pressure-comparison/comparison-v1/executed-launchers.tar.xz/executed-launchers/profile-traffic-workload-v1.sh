#!/usr/bin/env bash
set -euo pipefail
task_root=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261017-pressure-comparison
test ! -e "$task_root/trace-summaries-v2"
mkdir -p "$task_root/trace-summaries-v2/tmp"
export TMPDIR="$task_root/trace-summaries-v2/tmp" PYTHONDONTWRITEBYTECODE=1
for task_case in pressure-default-live pressure-scatter128-live intrinsic-live pressure-unfused-live; do
 task_cohort=trace-b2048-v1
 if test "$task_case" = pressure-unfused-live; then task_cohort=trace-pressure-unfused-v1; fi
 /usr/bin/python3 "$task_root/meta/summarize_trace-v2.py" --trace "$task_root/$task_cohort/$task_case/results/benchmark.trace.json" --output "$task_root/trace-summaries-v2/$task_case.json" > "$task_root/trace-summaries-v2/$task_case.log"
done
/usr/bin/python3 "$task_root/meta/summarize_pressure_profiles-v2.py" --root "$task_root" --summaries trace-summaries-v2 --output "$task_root/profile-audit-v2/profile-comparison.json"
if command -v ncu >/dev/null 2>&1; then ncu --version > "$task_root/trace-summaries-v2/nsight-compute-availability.txt"; else printf 'Nsight Compute CLI is not installed in the measured container.\n' > "$task_root/trace-summaries-v2/nsight-compute-availability.txt"; fi
