#!/usr/bin/env bash
set -eo pipefail
source /mnt/data/shared/config/env.sh
task_root=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261017-pressure-comparison
mkdir -p "$task_root/intrinsic-capacity-cache/cuda"
GENESIS_IMAGE_VER=1_26 gs-srun --ntasks=1 /usr/bin/env CUDA_CACHE_PATH="$task_root/intrinsic-capacity-cache/cuda" \
 /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python "$task_root/meta/run_pressure_comparison-v1.py" \
 --source "$task_root/source-v1" \
 --conditions /mnt/home/zhaofeng/workspace/Genesis/.worktrees/rigid-stress-recovery/research/rigid_stress/evidence/20261017-throughput/source-recipes-v1/inputs/conditions.npz \
 --output "$task_root/capacity-intrinsic-b40960-v1" --envs 40960 --scopes live --profiles intrinsic --memory --repetitions 1
