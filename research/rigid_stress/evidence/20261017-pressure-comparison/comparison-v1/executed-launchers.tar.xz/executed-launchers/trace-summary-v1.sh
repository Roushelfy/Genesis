#!/usr/bin/env bash
set -eo pipefail
source /mnt/data/shared/config/env.sh
case "$SLURM_ARRAY_TASK_ID" in 0) task_case=pressure-default-live;; 1) task_case=pressure-scatter128-live;; 2) task_case=intrinsic-live;; esac
task_root=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261017-pressure-comparison
mkdir -p "$task_root/trace-summaries-v1"
GENESIS_IMAGE_VER=1_26 gs-srun --ntasks=1 /usr/bin/python3 "$task_root/meta/summarize_trace-v1.py" \
 --trace "$task_root/trace-b2048-v1/$task_case/results/benchmark.trace.json" \
 --output "$task_root/trace-summaries-v1/$task_case.json"
