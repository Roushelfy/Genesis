#!/usr/bin/env bash
set -eo pipefail
source /mnt/data/shared/config/env.sh
GENESIS_IMAGE_VER=1_26 gs-srun --ntasks=1 bash \
 /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261017-pressure-comparison/reference-source-v1/research/rigid_stress/scripts/reconstruct_franka_packets.sh \
 /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261017-pressure-comparison/egg-rlm-v1 \
 /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261017-pressure-comparison/source-v1 \
 /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261017-repository-organization/restored-contact-packets \
 --radii 0.003 0.006 --models pressure body_source_prior
