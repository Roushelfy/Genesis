#!/usr/bin/env bash
set -euo pipefail
task_root=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261017-pressure-comparison
task_old=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261014-physical-validation
case "$1" in
 0) task_geometry=ellipsoid; task_radius=0.003 ;;
 1) task_geometry=ellipsoid; task_radius=0.0024 ;;
 2) task_geometry=narrow_gap; task_radius=0.003 ;;
 3) task_geometry=narrow_gap; task_radius=0.0024 ;;
esac
task_mesh="$task_old/matrix-mesh-$task_geometry-v1/meshes/h0.0035.npz"
task_run="$task_root/control-$task_geometry-r$task_radius-v1"
test ! -e "$task_run"
mkdir -p "$task_run/tmp"
export TMPDIR="$task_run/tmp" PYTHONPATH="$task_root/reference-source-v1:$task_root/source-v1" PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export GS_CACHE_FILE_PATH="$task_run/cache/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_run/cache/quadrants" QD_OFFLINE_CACHE=0
export NUMBA_CACHE_DIR="$task_run/cache/numba" MPLCONFIGDIR="$task_run/cache/matplotlib" CUDA_CACHE_PATH="$task_run/cache/cuda"
trap 'task_status=$?; trap - EXIT; set +e; printf "%s\n" "$task_status" > "$task_run/returncode.txt"; sha256sum "$task_mesh" > "$task_run/mesh-after.sha256"; exit "$task_status"' EXIT
sha256sum "$task_mesh" > "$task_run/mesh-before.sha256"
cd "$task_root/reference-source-v1"
/mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python - <<'PY' > "$task_run/import-origins.txt"
import genesis
from research.rigid_stress import load_model_validation
print(genesis.__file__)
print(load_model_validation.__file__)
assert '/20261017-pressure-comparison/source-v1/' in genesis.__file__
assert '/20261017-pressure-comparison/reference-source-v1/' in load_model_validation.__file__
PY
/mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.load_model_validation \
 --mesh "$task_mesh" --geometry "$task_geometry" --cases opposing asymmetric near_slip multiple \
 --models pressure body_source_prior --backend cpu --method direct --radius "$task_radius" \
 --output "$task_run/results" > "$task_run/program.log" 2>&1
cmp "$task_run/mesh-before.sha256" "$task_run/mesh-after.sha256" 2>/dev/null || sha256sum "$task_mesh" > "$task_run/mesh-after.sha256"
cmp "$task_run/mesh-before.sha256" "$task_run/mesh-after.sha256"
