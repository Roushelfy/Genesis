#!/usr/bin/env bash
set -eo pipefail
source /mnt/data/shared/config/env.sh
task_root=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261017-pressure-comparison
mkdir -p "$task_root/tuned-memory-cache/cuda"
GENESIS_IMAGE_VER=1_26 gs-srun --ntasks=1 /usr/bin/env CUDA_CACHE_PATH="$task_root/tuned-memory-cache/cuda" \
 /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python "$task_root/meta/run_pressure_comparison-v2.py" \
 --source "$task_root/source-v1" \
 --conditions /mnt/home/zhaofeng/workspace/Genesis/.worktrees/rigid-stress-recovery/research/rigid_stress/evidence/20261017-throughput/source-recipes-v1/inputs/conditions.npz \
 --output "$task_root/tuned-memory-b16384-v1" --envs 16384 --profiles pressure-default pressure-tuned --scopes live policy --memory --repetitions 1
