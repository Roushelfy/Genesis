#!/usr/bin/env bash
set -eo pipefail
source /mnt/data/shared/config/env.sh
case "$SLURM_ARRAY_TASK_ID" in 0) task_width=65536;; 1) task_width=131072;; esac
task_root=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261017-pressure-comparison
mkdir -p "$task_root/capacity-b$task_width-cache/cuda"
GENESIS_IMAGE_VER=1_26 gs-srun --ntasks=1 /usr/bin/env CUDA_CACHE_PATH="$task_root/capacity-b$task_width-cache/cuda" \
 /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python "$task_root/meta/run_pressure_comparison-v1.py" \
 --source "$task_root/source-v1" \
 --conditions /mnt/home/zhaofeng/workspace/Genesis/.worktrees/rigid-stress-recovery/research/rigid_stress/evidence/20261017-throughput/source-recipes-v1/inputs/conditions.npz \
 --output "$task_root/capacity-b$task_width-v1" --envs "$task_width" --scopes live --profiles pressure-default --memory --repetitions 1
