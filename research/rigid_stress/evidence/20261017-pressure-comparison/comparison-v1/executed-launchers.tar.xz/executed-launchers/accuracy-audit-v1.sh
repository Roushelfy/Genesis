#!/usr/bin/env bash
set -eo pipefail
source /mnt/data/shared/config/env.sh
task_root=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261017-pressure-comparison
mkdir -p "$task_root/accuracy-audit-v1"
GENESIS_IMAGE_VER=1_26 gs-srun --ntasks=1 /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python "$task_root/meta/summarize_pressure_accuracy-v1.py" --root "$task_root" --output "$task_root/accuracy-audit-v1/accuracy-summary.json"
