#!/usr/bin/env bash
set -euo pipefail
task_root=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261017-pressure-comparison
case "$1" in 0) task_capacity=32;; 1) task_capacity=128;; 2) task_capacity=256;; esac
task_run="$task_root/pressure-oracle-tasks$task_capacity-v1"
test ! -e "$task_run"
mkdir -p "$task_run/tmp"
export TMPDIR="$task_run/tmp" PYTHONPATH="$task_root/oracle-source-v1:$task_root/source-v1" PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export GS_CACHE_FILE_PATH="$task_run/cache/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_run/cache/quadrants" QD_OFFLINE_CACHE=0
export NUMBA_CACHE_DIR="$task_run/cache/numba" MPLCONFIGDIR="$task_run/cache/matplotlib" CUDA_CACHE_PATH="$task_run/cache/cuda"
trap 'task_status=$?; trap - EXIT; printf "%s\n" "$task_status" > "$task_run/returncode.txt"; exit "$task_status"' EXIT
cd "$task_root/source-v1"
/mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.native_trajectory_oracle \
 --envs 16 --steps 1500 --seed 623016 --output-mode full --scatter-tasks-per-env "$task_capacity" \
 --conditions /mnt/home/zhaofeng/workspace/Genesis/.worktrees/rigid-stress-recovery/research/rigid_stress/evidence/20261017-throughput/source-recipes-v1/inputs/conditions.npz \
 --egg-geometry mesh64 --collision-method mpr --contact-patch off \
 --output "$task_run/oracle.json" > "$task_run/program.log" 2>&1
