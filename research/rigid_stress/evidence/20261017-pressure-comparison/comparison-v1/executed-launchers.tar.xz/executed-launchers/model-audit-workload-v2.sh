#!/usr/bin/env bash
set -euo pipefail
task_root=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261017-pressure-comparison
task_run="$task_root/model-audit-v2"
test ! -e "$task_run"
mkdir -p "$task_run/tmp"
export TMPDIR="$task_run/tmp" PYTHONPATH="$task_root/reference-source-v1:$task_root/source-v1" PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMBA_CACHE_DIR="$task_run/cache/numba" MPLCONFIGDIR="$task_run/cache/matplotlib"
cd "$task_root/reference-source-v1"
trap 'task_status=$?; printf "%s\n" "$task_status" > "$task_run/returncode.txt"; exit "$task_status"' EXIT
/mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python "$task_root/meta/analyse_pressure_models-v2.py" \
 --root "$task_root" \
 --packets /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261017-repository-organization/restored-contact-packets \
 --output "$task_run/model-comparison.json" > "$task_run/program.log" 2>&1
