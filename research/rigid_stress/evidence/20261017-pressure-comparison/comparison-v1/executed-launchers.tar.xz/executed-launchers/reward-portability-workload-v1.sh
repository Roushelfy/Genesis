#!/usr/bin/env bash
set -euo pipefail
task_root=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261017-pressure-comparison
task_packet=/mnt/home/zhaofeng/workspace/Genesis/.worktrees/rigid-stress-recovery/research/rigid_stress/evidence/20261017-pressure-comparison/comparison-v1
task_run="$task_root/reward-portability-v1"
test ! -e "$task_run"
mkdir -p "$task_run/tmp"
export TMPDIR="$task_run/tmp" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
trap 'task_status=$?; printf "%s\n" "$task_status" > "$task_run/returncode.txt"; exit "$task_status"' EXIT
/mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python "$task_root/meta/analyse_pressure_rewards-v1.py" --root "$task_packet/reward-traces" --output "$task_run/reward-comparison.json" > "$task_run/program.log" 2>&1
/usr/bin/python3 - "$task_root" <<'CHECK'
import json,sys
from pathlib import Path
root=Path(sys.argv[1]);a=json.loads((root/'reward-audit-v1/reward-comparison.json').read_text());b=json.loads((root/'reward-portability-v1/reward-comparison.json').read_text())
a.pop('input_sha256');b.pop('input_sha256');assert a==b
(root/'reward-portability-v1/reproduction-qa.json').write_text(json.dumps({'all_scientific_values_identical':True,'recorded_environment_steps':230400,'different_fields':['input_sha256 path prefixes only'],'passed':True},indent=2)+'\n')
CHECK
