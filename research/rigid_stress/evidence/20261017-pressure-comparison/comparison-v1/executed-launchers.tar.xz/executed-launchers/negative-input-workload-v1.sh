#!/usr/bin/env bash
set -euo pipefail
task_root=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261017-pressure-comparison
task_run="$task_root/negative-input-v1"
test ! -e "$task_run"
mkdir -p "$task_run/tmp"
export TMPDIR="$task_run/tmp" PYTHONPATH="$task_root/source-v1" PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export GS_CACHE_FILE_PATH="$task_run/cache/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_run/cache/quadrants" QD_OFFLINE_CACHE=0 NUMBA_CACHE_DIR="$task_run/cache/numba" CUDA_CACHE_PATH="$task_run/cache/cuda"
cd "$task_root/source-v1"
trap 'task_status=$?; printf "%s\n" "$task_status" > "$task_run/returncode.txt"; exit "$task_status"' EXIT
/mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python "$task_root/meta/negative-input-v1.py" --output "$task_run/results" > "$task_run/program.log" 2>&1
