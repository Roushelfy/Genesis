#!/usr/bin/env bash
set -euo pipefail
task_root=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261017-pressure-comparison
task_run="$task_root/render-draft-v3"
test ! -e "$task_run"
mkdir -p "$task_run/tmp" "$task_run/mpl-cache"
export TMPDIR="$task_run/tmp" MPLCONFIGDIR="$task_run/mpl-cache" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
trap 'task_status=$?; printf "%s\n" "$task_status" > "$task_run/returncode.txt"; exit "$task_status"' EXIT
/mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python "$task_root/plot-source-v3/plot_comparison.py" --metadata "$task_root/metadata-checkpoint-v2/comparison.json" --models "$task_root/model-audit-v2/model-comparison.json" --rewards "$task_root/reward-audit-v1/reward-comparison.json" --output "$task_run/figures" --figures errors reward > "$task_run/program.log" 2>&1
