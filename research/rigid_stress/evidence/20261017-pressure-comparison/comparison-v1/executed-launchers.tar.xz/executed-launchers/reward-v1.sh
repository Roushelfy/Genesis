#!/usr/bin/env bash
set -eo pipefail
source /mnt/data/shared/config/env.sh
case "$SLURM_ARRAY_TASK_ID" in
 0) task_model=pressure; task_radius=1;;
 1) task_model=body_source_prior; task_radius=1;;
 2) task_model=pressure; task_radius=0.5;;
 3) task_model=body_source_prior; task_radius=0.5;;
esac
task_root=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261017-pressure-comparison
GENESIS_IMAGE_VER=1_26 gs-srun --ntasks=1 bash "$task_root/reward-source-v1/research/rigid_stress/scripts/run_practical_reward_proxy.sh" \
 "$task_root/reward-$task_model-r$task_radius-v1" "$task_root/source-v1" \
 --conditions /mnt/home/zhaofeng/workspace/Genesis/.worktrees/rigid-stress-recovery/research/rigid_stress/evidence/20261017-throughput/source-recipes-v1/inputs/conditions.npz \
 --model "$task_model" --radius-scale "$task_radius" --history 0 --low-limit 0.2
