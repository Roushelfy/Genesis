#!/usr/bin/env bash
set -euo pipefail
task_root=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261017-pressure-comparison
task_deps=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/assets/pymupdf-1.26.5
test ! -e "$task_deps"
mkdir -p "$task_root/pdf-qa-install-v1/tmp"
export TMPDIR="$task_root/pdf-qa-install-v1/tmp" PIP_CACHE_DIR=/mnt/data/zhaofeng/pip_cache PYTHONDONTWRITEBYTECODE=1
/mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m pip install --no-deps --target "$task_deps" --report "$task_root/pdf-qa-install-v1/install-report.json" 'pymupdf==1.26.5'
