#!/usr/bin/env bash
set -eo pipefail
source /mnt/data/shared/config/env.sh
task_root=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261017-pressure-comparison
GENESIS_IMAGE_VER=1_26 gs-srun --ntasks=1 /usr/bin/python3 "$task_root/meta/summarize_trace-v1.py" --trace "$task_root/trace-pressure-unfused-v1/pressure-unfused-live/results/benchmark.trace.json" --output "$task_root/trace-summaries-v1/pressure-unfused-live.json"
