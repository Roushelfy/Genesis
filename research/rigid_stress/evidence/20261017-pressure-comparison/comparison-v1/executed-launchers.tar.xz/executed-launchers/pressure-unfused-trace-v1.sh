#!/usr/bin/env bash
set -eo pipefail
source /mnt/data/shared/config/env.sh
task_root=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261017-pressure-comparison
mkdir -p "$task_root/pressure-unfused-trace-cache/cuda"
GENESIS_IMAGE_VER=1_26 gs-srun --ntasks=1 /usr/bin/env CUDA_CACHE_PATH="$task_root/pressure-unfused-trace-cache/cuda" \
 /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python "$task_root/meta/run_pressure_comparison-v3.py" \
 --source "$task_root/source-v1" \
 --conditions /mnt/home/zhaofeng/workspace/Genesis/.worktrees/rigid-stress-recovery/research/rigid_stress/evidence/20261017-throughput/source-recipes-v1/inputs/conditions.npz \
 --output "$task_root/trace-pressure-unfused-v1" --envs 2048 --scopes live --trace --repetitions 1 \
 --profiles pressure-unfused
