#!/usr/bin/env bash
set -euo pipefail
task_root=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261017-pressure-comparison
task_run="$task_root/counter-probe-v1"
test ! -e "$task_run"
mkdir -p "$task_run/tmp" "$task_run/cache/cuda"
export TMPDIR="$task_run/tmp" CUDA_CACHE_PATH="$task_run/cache/cuda" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1
nvidia-smi --query-gpu=name,uuid,driver_version --format=csv > "$task_run/hardware.csv"
set +e
ncu --target-processes all --launch-count 1 --clock-control none --cache-control none --metrics dram__bytes_read.sum,dram__bytes_write.sum --csv --log-file "$task_run/counters.csv" /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python "$task_root/meta/counter-probe-v1.py" > "$task_run/program.log" 2>&1
task_status=$?
printf '%s\n' "$task_status" > "$task_run/returncode.txt"
exit "$task_status"
