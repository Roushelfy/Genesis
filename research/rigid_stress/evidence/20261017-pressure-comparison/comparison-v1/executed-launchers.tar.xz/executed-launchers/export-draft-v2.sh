#!/usr/bin/env bash
set -eo pipefail
source /mnt/data/shared/config/env.sh
task_root=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261017-pressure-comparison
mkdir -p "$task_root/export-draft-v2-tmp"
GENESIS_IMAGE_VER=1_26 gs-srun --ntasks=1 /usr/bin/env TMPDIR="$task_root/export-draft-v2-tmp" PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/assets/pymupdf-1.26.5 /mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python "$task_root/meta/qa_exports-v2.py" --figures "$task_root/render-draft-v3/figures" --output "$task_root/export-draft-v2" --names model-error-cost reward-phase
