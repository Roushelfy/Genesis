#!/usr/bin/env bash
set -eo pipefail
source /mnt/data/shared/config/env.sh
task_root=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261017-pressure-comparison
mkdir -p "$task_root/profile-audit-v1"
GENESIS_IMAGE_VER=1_26 gs-srun --ntasks=1 /usr/bin/python3 "$task_root/meta/summarize_pressure_profiles-v1.py" --root "$task_root" --output "$task_root/profile-audit-v1/profile-comparison.json"
