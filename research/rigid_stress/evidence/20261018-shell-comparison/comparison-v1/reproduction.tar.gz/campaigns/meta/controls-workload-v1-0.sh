#!/usr/bin/env bash
set -euo pipefail
task_root=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261018-shell-comparison
task_run="$task_root/controls-v1/group0"
test ! -e "$task_run"
mkdir -p "$task_run/tmp" "$task_run/cache"
export TMPDIR="$task_run/tmp" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export GS_CACHE_FILE_PATH="$task_run/cache/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_run/cache/quadrants" CUDA_CACHE_PATH="$task_run/cache/cuda" NUMBA_CACHE_DIR="$task_run/cache/numba"
export PYTHONPATH=/mnt/home/zhaofeng/workspace/Genesis/.worktrees/kashu-shell-pr22:/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261018-shell-comparison/tools-v1
cd /mnt/home/zhaofeng/workspace/Genesis/.worktrees/kashu-shell-pr22
trap 'task_status=$?; printf "%s\n" "$task_status" > "$task_run/returncode.txt"; exit "$task_status"' EXIT
/mnt/data/zhaofeng/venvs/genesis-shell-contact/bin/python -m research.rigid_stress.shell_comparison.controls --kind field --resolution 8 --precision 32 --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261018-shell-comparison/controls-v1/group0/field-n8-fp32 > "$task_run/field-n8-fp32.log" 2>&1
/mnt/data/zhaofeng/venvs/genesis-shell-contact/bin/python -m research.rigid_stress.shell_comparison.controls --kind field --resolution 8 --precision 64 --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261018-shell-comparison/controls-v1/group0/field-n8-fp64 > "$task_run/field-n8-fp64.log" 2>&1
/mnt/data/zhaofeng/venvs/genesis-shell-contact/bin/python -m research.rigid_stress.shell_comparison.controls --kind field --resolution 16 --precision 64 --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261018-shell-comparison/controls-v1/group0/field-n16-fp64 > "$task_run/field-n16-fp64.log" 2>&1
