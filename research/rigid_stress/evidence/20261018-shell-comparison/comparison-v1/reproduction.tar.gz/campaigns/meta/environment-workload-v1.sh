#!/usr/bin/env bash
set -euo pipefail
task_root=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261018-shell-comparison
task_run=$task_root/environment-v1
mkdir -p "$task_run/tmp" "$task_run/cache"
export TMPDIR="$task_run/tmp" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export GS_CACHE_FILE_PATH="$task_run/cache/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_run/cache/quadrants" CUDA_CACHE_PATH="$task_run/cache/cuda" NUMBA_CACHE_DIR="$task_run/cache/numba"
export PYTHONPATH=/mnt/home/zhaofeng/workspace/Genesis/.worktrees/kashu-shell-pr22
cd "$PYTHONPATH"
/mnt/data/zhaofeng/venvs/genesis-shell-contact/bin/python - <<'PY'
import sys, json, platform, importlib.metadata as m
import genesis as gs
import torch
print(json.dumps({'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'genesis':gs.__file__,'packages':{k:m.version(k) for k in ['quadrants','torch','numpy','scipy','trimesh','pydantic']}}))
gs.init(backend=gs.gpu,precision='32',logging_level='warning')
print('CUDA',torch.cuda.get_device_name(),torch.cuda.get_device_properties(0))
scene=gs.Scene(show_viewer=False)
egg=scene.add_entity(morph=gs.morphs.Sphere(radius=0.02),material=gs.materials.Shell(E=1e10,thickness=0.0004))
scene.build(n_envs=2)
scene.step()
print('SMOKE PASSED',egg.get_verts_pos().shape)
PY
