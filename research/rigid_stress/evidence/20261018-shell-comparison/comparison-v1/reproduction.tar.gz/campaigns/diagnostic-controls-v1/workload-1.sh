#!/usr/bin/env bash
set -euo pipefail
task_run=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261018-shell-comparison/diagnostic-controls-v1/group1
test ! -e "$task_run"
mkdir -p "$task_run/tmp" "$task_run/cache"
export TMPDIR="$task_run/tmp" PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export GS_CACHE_FILE_PATH="$task_run/cache/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_run/cache/quadrants"
export CUDA_CACHE_PATH="$task_run/cache/cuda" NUMBA_CACHE_DIR="$task_run/cache/numba"
export MPLCONFIGDIR="$task_run/cache/matplotlib"
export PYTHONPATH=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261018-shell-comparison/diagnostic-controls-v1/analysis-source:/mnt/home/zhaofeng/workspace/Genesis/.worktrees/kashu-shell-pr22-diagnostics
cd /mnt/home/zhaofeng/workspace/Genesis/.worktrees/kashu-shell-pr22-diagnostics
trap 'task_status=$?; printf "%s\n" "$task_status" > "$task_run/returncode.txt"; exit "$task_status"' EXIT
/mnt/data/zhaofeng/venvs/genesis-shell-contact/bin/python -m research.rigid_stress.shell_comparison.controls --kind contact --instrumented --resolution 16 --substeps 4 --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261018-shell-comparison/diagnostic-controls-v1/group1/drop-n16-sub4 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261018-shell-comparison/diagnostic-controls-v1/group1/drop-n16-sub4.log 2>&1
/mnt/data/zhaofeng/venvs/genesis-shell-contact/bin/python -m research.rigid_stress.shell_comparison.controls --kind contact --instrumented --resolution 16 --motion press-slide --friction 0 --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261018-shell-comparison/diagnostic-controls-v1/group1/press-n16-mu0 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261018-shell-comparison/diagnostic-controls-v1/group1/press-n16-mu0.log 2>&1
/mnt/data/zhaofeng/venvs/genesis-shell-contact/bin/python -m research.rigid_stress.shell_comparison.controls --kind contact --instrumented --resolution 16 --motion press-slide --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261018-shell-comparison/diagnostic-controls-v1/group1/press-n16-mu06 > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261018-shell-comparison/diagnostic-controls-v1/group1/press-n16-mu06.log 2>&1
