#!/usr/bin/env bash
set -euo pipefail
task_run=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261018-shell-comparison/cache-ablation-v1/group0
test ! -e "$task_run"
mkdir -p "$task_run/tmp" "$task_run/cache"
export TMPDIR="$task_run/tmp" PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export GS_CACHE_FILE_PATH="$task_run/cache/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_run/cache/quadrants"
export CUDA_CACHE_PATH="$task_run/cache/cuda" NUMBA_CACHE_DIR="$task_run/cache/numba"
export MPLCONFIGDIR="$task_run/cache/matplotlib"
export PYTHONPATH=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261018-shell-comparison/cache-ablation-v1/analysis-source:/mnt/home/zhaofeng/workspace/Genesis/.worktrees/kashu-shell-pr22
cd /mnt/home/zhaofeng/workspace/Genesis/.worktrees/kashu-shell-pr22
trap 'task_status=$?; printf "%s\n" "$task_status" > "$task_run/returncode.txt"; exit "$task_status"' EXIT
/mnt/data/zhaofeng/venvs/genesis-shell-contact/bin/python -m research.rigid_stress.shell_comparison.cache_ablation --conditions /mnt/home/zhaofeng/workspace/Genesis/.worktrees/rigid-stress-recovery/research/rigid_stress/evidence/20261017-throughput/source-recipes-v1/inputs/conditions.npz --inputs /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261018-shell-comparison/prepare-inputs-v2/group0/matched-inputs --model shell --substeps 10 --envs 16 --precision 64 --iterations 300 --tolerance 1e-8 --coarse-interval 1 --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261018-shell-comparison/cache-ablation-v1/group0/ablation > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261018-shell-comparison/cache-ablation-v1/group0/ablation.log 2>&1
