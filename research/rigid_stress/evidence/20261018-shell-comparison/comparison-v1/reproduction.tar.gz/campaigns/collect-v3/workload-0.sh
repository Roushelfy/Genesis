#!/usr/bin/env bash
set -euo pipefail
task_run=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261018-shell-comparison/collect-v3/group0
test ! -e "$task_run"
mkdir -p "$task_run/tmp" "$task_run/cache"
export TMPDIR="$task_run/tmp" PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export GS_CACHE_FILE_PATH="$task_run/cache/genesis" QD_OFFLINE_CACHE_FILE_PATH="$task_run/cache/quadrants"
export CUDA_CACHE_PATH="$task_run/cache/cuda" NUMBA_CACHE_DIR="$task_run/cache/numba"
export MPLCONFIGDIR="$task_run/cache/matplotlib"
export PYTHONPATH=/mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261018-shell-comparison/collect-v3/analysis-source:/mnt/home/zhaofeng/workspace/Genesis/.worktrees/rigid-stress-recovery
cd /mnt/home/zhaofeng/workspace/Genesis/.worktrees/rigid-stress-recovery
trap 'task_status=$?; printf "%s\n" "$task_status" > "$task_run/returncode.txt"; exit "$task_status"' EXIT
/mnt/data/zhaofeng/venvs/rigid-stress-physical/bin/python -m research.rigid_stress.shell_comparison.collect --runs /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261018-shell-comparison --output /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261018-shell-comparison/collect-v3/group0/summary > /mnt/data/zhaofeng/projects/workspace/Genesis/rigid-stress-recovery/runs/20261018-shell-comparison/collect-v3/group0/summary.log 2>&1
